#load dataset
context <- read.csv("http://becs.aalto.fi/~jtsuvile/coursematerials/context.csv")

# Q1: get vector names
names(context)
# "ID", "group", "understanding", "recollection","gender","age","education"    

# Q2: 3. Sometimes, you would want to inspect your data, to make sure you are working with the right variables. 
# Display first 5 and last 5 entries from your data frame. 
# How would you check the dimensions of the data? 
# Display the recollection score for subjects 5-12. 

#show first
head(context)
# show last
tail(context)
#get size
dim(context)
# access recollection for subects 5-12
context$recollection[5:12]

# Q3: Create separate vectors from the data in context dataframe. Call each vector with its name from data frame. 
ID <- context$ID
group <- context$group
understanding <- context$understanding
recollection <- context$recollection
gender <- context$gender
age <- context$age
education <- context$education 

# OR 
attach(context)

# Q4 : Now take your vectors, and combine them back into a new data frame. 

context2 <- data.frame(ID, group, understanding, recollection, gender, age, education)

# Q5: Find a function, that swaps the matrix in such a way, that rows correspond to variables, and columns to cases

context3 <- t(context)
# easiest function for doing this is t()

# Q6: Find out the range of recollection variable. Check, if there are some strange numbers assigned to this variable and replace them with NA

range(context$recollection)
# 3 999

# let's see the distribution of values (not necessary)
hist(context$recollection)
# seems like 999 is a way for coding missing values
# remove 999's
context$recollection[context$recollection==999] <-NA 
# check new range
range(context$recollection, na.rm=TRUE)
# better!

# Q7: What are the types of data in this data frame? 
# either manually:
class(context$ID)
class(context$group)
class(context$understanding)
class(context$recollection)
class(context$gender)
class(context$age)
class(context$education)
# or easier way:
sapply(context,class)

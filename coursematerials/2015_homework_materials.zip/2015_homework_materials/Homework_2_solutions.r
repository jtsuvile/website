# Q1:

#Load the data first:
dataset = read.csv('http://users.aalto.fi/~ejtehaf1/readingstrategies.csv')

# Q2:

# When you don't know the range of results beforehand, i.e. can't prepare a threshold for selecting the best/worst results,
# you can use quantiles. For example, calculate the 95% percentile to get the best 5% of the sample.
quantile(dataset$recollection,0.95, na.rm =TRUE) 

# Find the 33rd (one-third) and 66th (two-third) percentiles of the data 
quantile(dataset$recollection,c(0.33,0.66),na.rm=TRUE)
# The 33rd and 66th percentiles of "recollection" are 0.66 and 0.83 respectively.

# Then take the results which are higher, and consider them being the “high” group.
# And take the results which are lower, and consider them as the "low" group.
# if recollection <0.66, low
# if recollection =>0.66 but <0.83, medium
# if recollection >0.83, high 
dataset$rec_gr='medium' 
dataset$rec_gr[which(dataset$recollection>0.83)]='high' 
dataset$rec_gr[which(dataset$recollection<0.66)]='low'

# Can also create a factor 'rec_gr' based on recollection scores
dataset$rec_gr <- factor(dataset$rec_gr)

# Check out the data now
head(dataset$rec_gr) # there are three groups

summary(dataset$rec_gr)

# Check that the grouping works
dataset # under rec_gr column can find the subgroup categories of low, medium, high 

# Q3:

mean(dataset$header, na.rm=TRUE) # NA not included, mean is 66.75056
sd(dataset$last, na.rm=TRUE) # NA not included, standard deviation is 13.90426

# Q4

# First install and load 'psych' package which has 'describe' function
install.packages('psych')
library('psych')

# Use 'describe' to get statistics of variables 'header', 'topic', 'other', 'last'
describe(dataset$header) # mean higher than median -> 'header' values typically larger than median
describe(dataset$topic) # mean higher than median -> 'topic' values typically larger than median
describe(dataset$other) # mean lower than median -> 'other' values typically smaller than median
describe(dataset$last) # mean slightly higher than median -> -> 'last' values typically close to median

# Then we check skewness values outputted by 'describe':
# Negative skewness indicates that the mean is less than the median and the data distribution is left-skewed.
# Positive skewness indicates that the mean is larger than the median and the data distribution is right-skewed.
# All four variables have positive skewness. 
# Skewness is higher (2.8) for 'header' which makes sense since 'header' mean (66.75) is clearly much higher than median (51.68) 
# Skewness is close to being negative (0.01) for 'other' which makes sense since 'other' mean (38.22) is lower than median (39.77) 
# Simple comparison of mean and median would have answered this question as well.

# Q5:

# Again use 'describe'.
# Then examine kurtosis values. 
# Kurtosis is a measure of the peakedness of the data distribution. 
# Negative kurtosis indicates a flat data distribution.
# Positive kurtosis would indicates a peaked distribution. 
# The normal distribution has zero kurtosis.

# So, Negative kurtosis: loose, Positive kurtosis: packed.
describe(dataset$header) # kurtosis (9.11) is postive -> quite tightly packed observations
describe(dataset$topic) # kurtosis (-0.79) is negative -> loose observations
describe(dataset$other) # kurtosis (-0.48) is negative -> loose observations
describe(dataset$last) # kurtosis (1.95) is postive -> packed observations

# Q6:

# Keep the horizontal lines only when necessary, no vertical lines. 
# Mean and SD are usually enough for descriptive purposes, 
# yet as long as you need to use other measures – it's perfectly fine to include them as well.

# Example1: Descriptive statistics for 'recollection' by 'gender'
# Get mean and standard deviation of 'recollection' for males and females:
mean <- tapply(dataset$recollection, dataset$gender, mean, na.rm=T)
sd <- tapply(dataset$recollection, dataset$gender, sd, na.rm=T)
dataset_rec_gen <- rbind(mean, sd)
dataset_rec_gen
#       female      male
#mean 0.7972500 0.7066000
#sd   0.1481102 0.1487957
write.csv(dataset_rec_gen, "recollection_by_gender")

# Example2: Descriptive statistics for 'working memory score' and 'recollection'  
memory_recollection <- describe(dataset[c(2,5)])
memory_recollection
write.csv(memory_recollection, "memory_recollection_stats.csv")

# Q7:

#Load the dataset:
emotions=read.csv('http://users.aalto.fi/~ejtehaf1/emotions.csv') 

# Create boxplots of different emotion variables
boxplot(emotions[6:11],main="Emotional variables", ylab="Intensity", xlab="Emotions") 

# Create boxplots showing how different emotions are represented in different gender groups
boxplot(emotions$pleasure~emotions$gender,main="Pleasure",ylab="Intensity")
boxplot(emotions$disgust~emotions$gender,main="Disgust",ylab="Intensity")
boxplot(emotions$anger~emotions$gender,main="Anger",ylab="Intensity")
boxplot(emotions$fear~emotions$gender,main="Fear",ylab="Intensity")
boxplot(emotions$sadness~emotions$gender,main="Sadness",ylab="Intensity")
boxplot(emotions$surprise~emotions$gender,main="Surprise",ylab="Intensity")
# Note the outlliers, compare males & females (eg. by observing their difference in median, max, min, 1st & 3rd quantile lines)

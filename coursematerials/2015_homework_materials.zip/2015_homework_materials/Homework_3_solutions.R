#Question 1
naming=read.csv("http://becs.aalto.fi/~jtsuvile/coursematerials/naming.csv",sep = "\t")


naming$iq[naming$iq==999]<-NA # Weird values are removes
naming$male<-factor(naming$male)
attach(naming)

summary(naming)

#Question 2
layout(c(1,2,3))
hist(iq)
hist(ms)
hist(hrs)


# Question 3
shapiro.test(iq)
shapiro.test(hrs)
shapiro.test(ms)

# hrs seem to satisify the normality test best.
# it has the highest distance (W) and the highest p-value.

# Question 4

#example
layout(1)
data1=rnorm(1000,10,1)
data2=rnorm(1000,12,1)
limit=c(min(range(data1),range(data2)),max(range(data1),range(data2)))
hist(data1,col=rgb(0,0,1,0.4),xlim=limit)
hist(data2,col=rgb(1,0,0,0.4),xlim=limit,add=T)

layout(1)
data1=ms[word.type=="regular"]
data2=ms[word.type=="exception"]
limit=c(min(range(data1),range(data2)),max(range(data1),range(data2)))
hist(data1,col=rgb(0,0,1,0.4),xlim=limit)
hist(data2,col=rgb(1,0,0,0.4),xlim=limit,add=T)

#Question 5
shapiro.test(data1)
shapiro.test(data2)
mean(data1)
sd(data1)

mean(data2)
sd(data2)

# The means are  almost 1000 and 12000 respectively 
# while the standard deviations are about 75 and 80
# This means that there is a distance of almost three standard deviations between the means.
# This is expected to show significant p-value in a t-test later.

# Question 6
data1<-hrs
mean(data1)
sd(data2)
shapiro.test(data1)
data2<-rnorm(length(data1),mean(data1),sd(data1))
limit=c(min(range(data1),range(data2)),max(range(data1),range(data2)))
hist(data1,col=rgb(0,0,1,0.4),xlim=limit)
hist(data2,col=rgb(1,0,0,0.4),xlim=limit,add=T)

# The two distributions look very similar. The hrs variable follows a normal distribution



#Homework for demo session 4
# In all statistical tests, report the results in APA style as in instructed in the exercises.
#Q1 load data, fix variables and attach data
#Load data
rm(list=ls())
read.csv('animalratings3.csv',sep=",",header=T)->animaldata
#Duplicate data to not modify original
animals<-animaldata

#Fix Variables
animals$Fear.rating<-as.numeric(animals$Fear.rating)
animals$Disgust.rating<-as.numeric(animals$Disgust.rating)
animals$Dangerous<-factor(animals$Dangerous)
animals$Size<-factor(animals$Size)
animals$ID<-factor(animals$ID)

#Looks good
#Attach dataset
attach(animals)

#Q2 a. Check whether the Disgust rating for spiders is above population average for all animals (=119). 
t.test(Disgust.rating[Animal=="spider"],mu=119)
#yes.

#   b. What about fear ratings for spiders. Estimate population mean Fear rating from data. Report in APA style (one sentence)
t.test(Fear.rating[Animal=="spider"],mu=mean(Fear.rating))
#yes
#   c. Test whether the above variables normally distributed. Can you trust the results of these t-tests? 
shapiro.test(Fear.rating[Animal=="spider"])
shapiro.test(Disgust.rating[Animal=="spider"])
#not normally distributed, t-tests not valid.

#Q3
#a. Compare Arousal ratings between dogs and wolves using Student's t'test and Welch's t test. Do the results differ? Which is more reliable?
t.test(Arousal.rating[Animal=="dog"],Arousal.rating[Animal=="wolf"],var.equal = T) # Student
t.test(Arousal.rating[Animal=="dog"],Arousal.rating[Animal=="wolf"]) # Welch
#Essentially same, p value slightly bigger for Welch. Welch more reliable.

#b. Test whether arousal and valence ratings differ for all dangerous animals. Test normality as usual.
shapiro.test(Valence.rating[Dangerous==1])
shapiro.test(Arousal.rating[Dangerous==1])
t.test(Valence.rating[Dangerous==1],Arousal.rating[Dangerous==1],paired=T)
#yep, different but valence not normal

#Q4 Use ANOVA tp test whether there's a difference in disgust ratings between dogs, pelican and snakes. If you find a significant difference, conduct
# post-hoc-tests to find out where the difference is. Test for normality and homogeneity of variances.
#New data frame for the three animal types.
animals2<-animals[(Animal=="snake")|Animal=="dog"|Animal=="pelican",]
#test for homogeneity of variances:
install.packages('car')
library('car')
leveneTest(animals2$Disgust.rating~animals2$Animal)
bartlett.test(animals2$Disgust.rating~animals2$Animal)
#Variences not equal.
X1<-aov(animals2$Disgust.rating~animals2$Animal)
summary(X1)
#Yup, different.
t.test(animals2$Disgust.rating[animals2$Animal=="dog"],animals2$Disgust.rating[animals2$Animal=="pelican"],var.equal=T)
t.test(animals2$Disgust.rating[animals2$Animal=="dog"],animals2$Disgust.rating[animals2$Animal=="snake"],var.equal=T)
t.test(animals2$Disgust.rating[animals2$Animal=="snake"],animals2$Disgust.rating[animals2$Animal=="pelican"],var.equal=T)
# Snake's differ from both dogs and pelicans, dogs and pelicans don't differ from each other

#Q5 It could be argued that the human aversive response towards other species, measured here by the Disgust ratings depends primarily 
#on taxonomical similarity (included as factor: 1=mammal, 2=non-mammal vertebrate,3=invertebrate) with humans
#but is modulated by whether the animal is considered as potentially threatening or not (measured here by the Dangerous factor).
#Construct a model which tests this hypothesis, and conduct post hoc tests as appropriate. Discuss possible limitations to your model, e.q.
#statistical assumptions, group sizes etc. Visualize the results using an interaction plot.

#Let's build the model first, it's 2(Dangerous) X 3(Taxonomic group) on Disgust ratings.
#Tässä modelissa ja myös allaolevissa anovissa taxononic group-faktorin groupsizet ei oo yhtä suuret. Jos opiskelijat huomaa tämän niin hienoa.
#Oleellista on et statistinen power määräytyy pienimmän ryhmän mukaan.
X2<-aov(Disgust.rating~Dangerous*Taxonomic.group)
summary(X2)

#Dangerous significant
#Taxonomic group significant
#Interaction significant

#lets visualize
#looks like there's a difference but again only in the dangerous group
interaction.plot(Taxonomic.group,Dangerous,Disgust.rating, type="b", col=c(1:3),
                 leg.bty="o", leg.bg="beige", lwd=2, pch=c(18,24,22), 
                 xlab="Taxonomic group", ylab="Disgust rating", main="Interaction plot")

#lets test each level of Dangerous separately with one-way anova
DD<-animals[Dangerous==1,]
ND<-animals[Dangerous==0,]

#dangerous 
X3<-aov(DD$Disgust.rating~DD$Taxonomic.group)
summary(X3)

#non-dangerous
X4<-aov(ND$Disgust.rating~DD$Taxonomic.group)
summary(X4)

#taxonomic group significant only for dangerous, conduct t-tests to nail it down. 

t.test(DD$Disgust.rating[DD$Taxonomic.group==1],DD$Disgust.rating[DD$Taxonomic.group==2],var.equal=T)
#Significant!
t.test(DD$Disgust.rating[DD$Taxonomic.group==1],DD$Disgust.rating[DD$Taxonomic.group==3],var.equal=T)
#Significant!
t.test(DD$Disgust.rating[DD$Taxonomic.group==2],DD$Disgust.rating[DD$Taxonomic.group==3],var.equal=T)
#Significant

#For dangerous animals, taxonomic group indeed affects disgust ratings. More distant species are perceived as more disgusting, digust ratings
#increase with increasing taxonomical distance.
#No significant differences in disgust between taxonomic groups for non-dangerous animals.


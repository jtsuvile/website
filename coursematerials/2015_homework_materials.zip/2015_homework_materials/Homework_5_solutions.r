# HW5 Solutions 
# updated on 9.10.2015 /Lara

timeofday <- read.csv('/home/ejtehaf1/Desktop/demo5_lara/timeofday.csv', sep=",", header=T)
distance <- read.csv('/home/ejtehaf1/Desktop/demo5_lara/distance.csv', sep=",", header=T)
castraffic <- read.csv('/home/ejtehaf1/Desktop/demo5_lara/castraffic.csv', sep=",", header=T)
temprate <- read.csv('/home/ejtehaf1/Desktop/demo5_lara/temprate.csv', sep=",", header=T)
depression <- read.csv('/home/ejtehaf1/Desktop/demo5_lara/depression.csv', sep=",", header=T)
fitness <- read.csv('/home/ejtehaf1/Desktop/demo5_lara/fitness.csv', sep=",", header=T)
exam <- read.csv('/home/ejtehaf1/Desktop/demo5_lara/exam.csv', sep=",", header=T)
child_data <- read.csv('/home/ejtehaf1/Desktop/demo5_lara/child_data.csv', sep=",", header=T)

# Q2) 
# For each dataset, compute descriptive statistics, make a table, displaying those. Inspect datasets for
# associations between the variables.
# Use summary() and describe() to check data for errors and produce needed descriptive statistics.
# You can always decide by yourself, which of the statistics to include in the table.
# cor(dataset) to inspect the associations between variables in the dataset.


# Q3) 
# Using linear regression and providing plots, answer following questions (first three datasets):

# a) Is it becoming more dangerous for cyclists to ride in the afternoon?
m1=lm(timeofday$Prxomity ~ timeofday$Hour)
summary(m1)
plot(timeofday$Prxomity ~ timeofday$Hour, xlab="Time", ylab="Overtaking distance")
abline(m1,col="red")
# Yes, it is becoming more dangerous for cyclists to ride in the afternoon
# Hour predicts Proximity (b=0.02, t(9)=3.73, p<.01)
# --> Hour explains 61% of the variance in Proximity (F(1,9)=13.95, p<.01, adjusted R^2 = 0.56)

# b) How does mileage of UK drivers change with years passing?
m2=lm(distance$Distance ~ distance$Year)
summary(m2)
plot(distance$Distance ~ distance$Year,xlab="Year",ylab="Mileage")
abline(m2,col="red")
# Mileage of UK drivers increases with years passing
# Year predicts Distance (b=147.4, t(42)=49.15, p<.001)
# --> Year explains 98% of the variance in Distance (F(1,42)=2416, p<.001, adjusted R^2 = 0.98)

# c) How does the number of road casualties change over time
m3=lm(castraffic$casualties ~ castraffic$Year)
summary(m3)
plot(castraffic$casualties ~ castraffic$Year, xlab="Year", ylab="Casualties")
abline(m3,col="red")
# No significant relationship between the number of road casualties and time(year)
# Year does not predict casualties -> p-value 0.129
# --> model does not fit data and explains only 4% of variance in casualties (F(1,53)=2.38, p>.1), adjusted R^2=0.02)

# d) Does number of road casualties depend on amount of km driven in a year?
m4=lm(castraffic$casualties ~ castraffic$Traffic.km)
summary(m4)
plot(castraffic$casualties ~ castraffic$Traffic.km, xlab="km per year", ylab="Casualties")
abline(m4,col="red")
# No significant relationship between the number of road casualties and the amount of km driven in a year
# Traffic.km does not predict casualties -> p-value 0.253
# --> model does not fit data and explains only 2% of variance in casualties (F(1,53)=1.33, p>.1), adjusted R^2=0.01)

# Q4)
# Load temprate.csv dataset. Does heart rate correlate with temperature?
corr.test(temprate)
# hrtrate correlates at r=.25 with temp. Heart rate has a weak positive correlation with temperature.
# If you wish, you can also do it “linear regression style” and have a plot there.

# Q5) 
# Load depression.csv dataset. Assess, how is depression correlated with fatalism and simplicity.
corr.test(depression)
# depression correlates at r=.66 with fatalism. Depression has a relatively strong positive correlation with fatalism.
# depression correlates at r=.64 with simplicity. Depression rate has a relatively strong positive correlation with simplicity.

# Q6) 
# Load fitness.csv dataset. Using correlation analysis, make your suggestion for losing weight, based on this dataset.
m5=lm(fitness$Weight ~ fitness$Situps)
m6=lm(fitness$Weight ~ fitness$Chinups)
m7=lm(fitness$Weight ~ fitness$Jumps)
m8=lm(fitness$Weight ~ fitness$Jumps*fitness$Situps)
m9=lm(fitness$Weight ~ fitness$Jumps*fitness$Chinups)
m10=lm(fitness$Weight ~ fitness$Situps*fitness$Chinups)

# Then check summary() of each model.
summary(m5) # Situps predicts Weight (b=-0.19, t(18)=-2.40, p<.05)
summary(m6) # Chinups predicts Weight (b=-1.82, t(18)=-1.79, p<.1)
summary(m7) # Jumps does not predict Weight 
summary(m8) # Jumps and Situps together do not predict Weight
summary(m9) # Jumps and Chinups together do not predict Weight
summary(m10) # Situps and Chinups together do not predict Weight
# The best way to lose weight is to do situps

# Q7) 
# Load exam.csv dataset. Does final score depend on amount of hours spent studying? Does it depend on anxiety?
m11=lm(exam$SCORE ~ exam$HOURS * exam$ANXIETY)
summary(m11)
# Hours predicts Score (b=0.93, t(16)=2.27, p<.05)
# Anxiety does not predict Score
# Interaction of Anxiety and Hours does not predict Score
# The final score depends only on amount of hours spent studying, but not on anxiety

# Q8)
# Finally, load child_data.csv dataset, and answer, does reading score (read.ab variable) depend on memory span or IQ?
m12=lm(child_data$READ.AB ~ child_data$MEM.SPAN)
m13=lm(child_data$READ.AB ~ child_data$IQ)
m14=lm(child_data$READ.AB ~ child_data$MEM.SPAN * child_data$IQ)

# Make summary() of each.
summary(m12) 
# mem.span predicts read.ab (b=0.98, t(18)=2.57, p<.001)
# memory span explains 67% of the variance in reading score (F(1,18)=37.09, p<.001, adjusted R^2 = 0.65)

summary(m13) # iq does not predicts read.ab
summary(m14) # interaction of mem.span and iq does not predict read.ab
# reading score depends only on memory span, but not on IQ

# Part 1.2
rm(list = ls())
deprivation<-read.csv("http://becs.aalto.fi/~heikkih3/deprivation.csv")
summary(deprivation)
#store original
deprivation.orig <- deprivation
#let's deal with some factors represented as numbers
deprivation$ID <- factor(deprivation$ID)

# make helper variable "edu" for factor labels in education
deprivation$edu <- "comprehensive"
deprivation$edu[deprivation$education==2] <- "secondary"
deprivation$edu[deprivation$education==3] <- "higher"
# turn the factor back to original variable
deprivation$education <- factor(deprivation$edu)
# and remove helper variable
deprivation <- deprivation[,-which(names(deprivation) == "edu")]

# another way to turn number to factor (with new labels)
deprivation$age = factor(deprivation$age,labels=c("young", "old"))
# if you use this way, make sure that your labels and original values match!
# let's check:
data.frame(deprivation.orig$age, deprivation$age)
# factors look good! Let's check numerical values:
summary(deprivation)

# Part 1.3
# install package, if you don't have it yet
install.packages('psych')
# load package for use in this session
library('psych')

# start using functions!
describe(deprivation)
summary(deprivation)

boxplot(deprivation, las=2)
# looks good, not likely to have big weird values!
# ready to attach
attach(deprivation)

# let's still visually compare digit symbol and benton tasks in different timepoints
layout(matrix(c(1,2),1,2))
boxplot(deprivation[,c("digitsymbol_1","digitsymbol_2","digitsymbol_3")],las=3)
boxplot(deprivation[,c("bentonerror_1","bentonerror_2","bentonerror_3")],las=3)

# Part 2.1
# Normal distribution
dev.off()
# runif creates uniformly distributed random numbers
unif_random <- runif(10000)*10
hist(unif_random, main="")

#create empty vector
means <- numeric(10000)

# the next bit will be a loop.
# if you're not very familiar with programming, 
# you should take some time to learn about how loops work.
# essentially, it's a handy way to do something very many times
# here, we use the loop to take means of random numbers and 
# put them into the means-vector
for (i in 1:10000) {
  means[i] <- mean(runif(5)*10)
}
# now let's visualize
hist(means, ylim=c(0,1600))

# let's add normal curve 
h <- hist(means, freq=F, ylim=c(0,0.35))
x <- seq(min(h$breaks),max(h$breaks), by=0.1)
y <- dnorm(x, mean=mean(means), sd=sd(means))
lines(x,y,col="red", lty="dashed", lwd=3)


# Part 2.2

# create a vector
simu <- seq(-4,4,0.01)  
# draw a normal distribution:
plot(simu, dnorm(simu), type="l", lty=2, 
     ylab="Probability density", xlab="Deviates")	
# add different t-distributions:
lines(simu, dt(simu, df=5), col="red")		# sample size = 5
lines(simu, dt(simu, df=10), col="green")	 # sample size = 10
legend("topright", c("normal", "t, df 5", "t, df 10"), bty="n", lty=c(2,1,1),col=c("black", "red", "green"))

# ETC. play around by increasing sample size. 

# What happens when you get close or beyond 30?

# Part 2.3

# create a vector
simu2 <- seq(0,4,0.01)
# draw an F-distribution
plot(simu2, df(simu2,1,1), type="l", lty=2, 
     ylab="Probability density", xlab="Deviates")

# try changing degrees of freedom:
lines(simu2, df(simu2, 1,10), col="red")  	# DF 1 = 1, DF = 10
lines(simu2, df(simu2, 10,10), col="green")	  # DF 1 = 10, DF = 10
legend("topright", c("normal", "t, df 1,10", "t, df 10,10"), bty="n", lty=c(2,1,1),col=c("black", "red", "green"))
lines(simu2, df(simu2, 1,10), col="red")		# df1 = 1, df2 = 10
lines(simu2, df(simu2, 1,40), col="magenta")	# df1 = 1, df2 = 40

lines(simu2, df(simu2, 2,40), col="blue")		# df1 = 2, df2 = 40
lines(simu2, df(simu2, 3,40), col="cyan")		# df1 = 3, df2 = 40
lines(simu2, df(simu2, 4,40), col="green")	# df1 = 4, df2 = 40
# ETC. play around by increasing both degrees of freedom separately.

# Question 1
# Generate random 100 numbers from a normal distribution using rnorm

data<-rnorm(100)
mean(data)
sd(data)
hist(data)

# What do you observe? Why?

#Question 2
# Repeat the same but add the mean and the standard deviation in the main title!
data<-rnorm(100,3,2)
mean(data)

hist(data,main=paste(mean(data),"  ","( sd:",sd(data),")"))

# Calculating the mean and the standard devtiation may give too many decimal numbers. 
# However, when we report results we often want to stick to just a few (e.g. 2-3).

# Question 3
# Repeat the same process but show only to decimals of the estimated mean and standard deviation.

mean(data)
# Try functions round, floor and ceiling and report their differences
round(mean(data),2)
floor(mean(data))
ceiling(mean(data))
# The round function allows a second argument about the number of digits but floor and ceiling do not. 
# How can we overcome this problem?
floor(mean(data)*100)/100
ceiling(mean(data)*100)/100
hist(data,main=paste(round(mean(data),2),"  ( sd:",round(sd(data),2),")"))


# We want to see how the mean and standard deviation behave on different sample sizes
# We want to calculate the mean over 10 samples. And we want to repeat this for 1000 times.
# We will make a matrix containing 10 times 1000 samples and we will calculate the mean over the 10 samples.


#Question 4
layout(matrix(c(1:4),2,2)) # Make a 2x2 plot matrix
nsamples=1 # 1 sample
ntimes=1000 # Repeated 1000 times
# Make tha matrix that contains the samples
datamat<-matrix(rnorm(nsamples*ntimes),nsamples,ntimes)
#Estimate the mean over the columns
means<-apply(datamat,2,mean) 
# Make the histogram with clim to have same limits
hist(means,xlim=c(-3,3), main="nsamples=1")

nsamples=10
ntimes=1000
datamat<-matrix(rnorm(nsamples*ntimes),nsamples,ntimes)
means<-apply(datamat,2,mean)
hist(means,xlim=c(-3,3),main="nsamples=10")

nsamples=100
ntimes=1000
datamat<-matrix(rnorm(nsamples*ntimes),nsamples,ntimes)
means<-apply(datamat,2,mean)
hist(means,xlim=c(-3,3),main="nsamples=100")

nsamples=1000
ntimes=1000
datamat<-matrix(rnorm(nsamples*ntimes),nsamples,ntimes)
means<-apply(datamat,2,mean)
hist(means,xlim=c(-3,3),main="nsamples=1000")

# Question 6
layout(1)
nsamples=50 # Number of dices (samples)
ntimes=1000 # Number of repetitions
# Generate continuous numbers from uniform distribution from 1 to 7 ,..
samples<-runif(nsamples*ntimes,1,7);
# ... and round them to the lower integer
samples2<-floor(samples)

# Make the data matrix
datamat<-matrix(samples2,nsamples,ntimes)

# Apply the sum over the columns (dices)
sums<-apply(datamat,2,sum)
dev.off()
# Plot the histogram with adapted limits for integers
hist(sums,breaks=seq(min(sums)-0.5,max(sums)+0.5),freq=F)


# Question 7
h <- hist(sums,breaks=seq(min(sums)-0.5,max(sums)+0.5),freq=F)
x <- seq(min(h$breaks),max(h$breaks), by=1)
y <- dnorm(x, mean=mean(sums), sd=sd(sums))
lines(x,y,col="red", lty="dashed", lwd=3)

# 
# Tests for normality
# 

describe(deprivation)
# mean, st dev, median, skewness

# Plot all numeric variables in same layout matrix:
layout(matrix(c(1,2,3,4,5,6), 3, 2))
hist(digitsymbol_1, main="Digit symbol 1")
hist(digitsymbol_2, main="Digit symbol 2")
hist(digitsymbol_3, main="Digit symbol 3")
hist(bentonerror_1, main="Benton error 1")
hist(bentonerror_2, main="Benton error 2")
hist(bentonerror_3, main="Benton error 3")

qqnorm(digitsymbol_1)
qqline(digitsymbol_1)


# Either with Shapiro-Wilk test:
shapiro.test(digitsymbol_1)  # Shapiro-Wilk

# Or with Kolmogorov-Smirnov test:
ks.test(digitsymbol_1, "pnorm", mean=mean(digitsymbol_1), sd=sd(digitsymbol_1))
# if you get warning
# "ties should not be present for the Kolmogorov-Smirnov test"
# it means that you have duplicate values in your data
# i.e. length(unique(digitsymbol_1)) < length(digitsymbol_1)
# usually, it's not a problem

#Question 8
layout(matrix(c(1,2,3,4,5,6),2,3,byrow=TRUE))
qqnorm(bentonerror_1,main="Benton Error Day1")
qqline(bentonerror_1)

qqnorm(bentonerror_2,main="Benton Error Day2")
qqline(bentonerror_2)

qqnorm(bentonerror_3,main="Benton Error Day3")
qqline(bentonerror_3)

qqnorm(digitsymbol_1,main="Digit Symbol Day1")
qqline(digitsymbol_1)

qqnorm(digitsymbol_2,main="Digit Symbol Day1")
qqline(digitsymbol_2)

qqnorm(digitsymbol_3,main="Digit Symbol Day1")
qqline(digitsymbol_3)

#Question 9
sw <- matrix(c(0,0,0,0,0,0),3,2)
p_vals <- matrix(c(0,0,0,0,0,0),3,2)
t <- shapiro.test(bentonerror_1)
sw[1,1]<-t$statistic
p_vals[1,1] <- t$p.value
t <- shapiro.test(bentonerror_2)
sw[2,1]<-t$statistic
p_vals[2,1] <- t$p.value
t <- shapiro.test(bentonerror_3)
sw[3,1]<-t$statistic
p_vals[3,1] <- t$p.value

t <- shapiro.test(digitsymbol_1)
sw[1,2]<-t$statistic
p_vals[1,2] <- t$p.value
t <- shapiro.test(digitsymbol_2)
sw[2,2]<-t$statistic
p_vals[2,2] <- t$p.value
t <- shapiro.test(digitsymbol_3)
sw[3,2]<-t$statistic
p_vals[3,2] <- t$p.value

#Question 10
ks=matrix(c(0,0,0,0,0,0),3,2)
ks_pvals=matrix(c(0,0,0,0,0,0),3,2)
# let's do it with a loop this time
vectorlist = list(bentonerror_1, bentonerror_2, bentonerror_3, digitsymbol_1, digitsymbol_2, digitsymbol_3)
# for running a loop over a list we must cheat a little and create an index counter
counter <-1
for (vector in vectorlist){
  t <- ks.test(vector,"pnorm")
  ks[counter]<-t$statistic
  ks_pvals[counter] <- t$p.value
  counter = counter+1
  print(t)
}

# Question 11
# The two tests give different values, but there is very high correlation. 
# The lowest score for normality is for Benton test Day 3, the highest is for Digit Symbol Day 1.

# Question 12

# Add the data in some other variable to make the change easier
Data1=bentonerror_2
Data2=bentonerror_3

graphics.off()
bins=seq(0,15,1)
p1 <- hist(Data1,breaks=bins)         
p2 <- hist(Data2,breaks=bins)             
plot( p1, col=rgb(0,0,1,1/4))   # first histogram
plot( p2, col=rgb(1,0,0,1/4),breaks=seq(0,20,2), add=T)  # second

legend('topright',c('Benton test Day 2','Benton test Day 3'),
       fill = c(Col1, Col2), bty = 'n', border = NA)

# Question 13
densData1 <- density(Data1)
densData2 <- density(Data2)
## calculate the range of the graph
xlim <- range(densData1$x,densData2$x)
ylim <- range(0,densData1$y, densData2$y)
#pick the colours
Col1 <- rgb(1,0,0,0.2)
Col2 <- rgb(0,0,1,0.2)
## Make the plot
plot(densData1, xlim = xlim, ylim = ylim ,main="")
# Put the densities
polygon(densData1, density = -1, col = Col1)
polygon(densData2, density = -1, col = Col2)
## add a legend in the corner
legend('topright',c('Benton Day 2','Benton Day 3'),
       fill = c(Col1, Col2), bty = 'n', border = NA)





rm(list=ls())
# Load data
#values are separated by ","'s, first row is variable names.
read.csv('animalratings2.csv',sep=",",header=T)->animaldata
animals<-animaldata

#Look at data
head(animals)
dim(animals)
summary(animals)
describe(animals)

#Fix Variables
animals$Fear.rating<-as.numeric(animals$Fear.rating)
animals$Disgust.rating<-as.numeric(animals$Disgust.rating)
animals$Dangerous<-factor(animals$Dangerous)
animals$Size<-factor(animals$Size)
animals$ID<-factor(animals$ID)

#Check for outliers
boxplot(animals$Arousal.rating)
boxplot(animals$Valence.rating)
boxplot(animals$Disgust.rating)
boxplot(animals$Fear.rating)

#Looks good
#Attach dataset
attach(animals)

#Let's see whether people like some animals ore than others. This is represented by
#the valence ratings they give to different animals.
#First, test for normality for Valence rating of each animal
#Remember that most normality tests have the NULL hypothesis that the sample distribution
#is NOT different from the normal distribution!!

shapiro.test(Valence.rating[Animal=="cat"])
shapiro.test(Valence.rating[Animal=="snake"])
shapiro.test(Valence.rating[Animal=="spider"])
shapiro.test(Valence.rating[Animal=="shark"])
shapiro.test(Valence.rating[Animal=="moose"])
shapiro.test(Valence.rating[Animal=="tiger"])
shapiro.test(Valence.rating[Animal=="cow"])
shapiro.test(Valence.rating[Animal=="butterfly"])
shapiro.test(Valence.rating[Animal=="dog"])
#Woops! Dog and butterfly ratings are not normally distributed, lets see what the histogram looks like
hist(Valence.rating[Animal=="butterfly"])
hist(Valence.rating[Animal=="dog"])
#Yep, definately not normal
#Let's check the other animals
shapiro.test(Valence.rating[Animal=="wolf"])
shapiro.test(Valence.rating[Animal=="pelican"])
shapiro.test(Valence.rating[Animal=="hyena"])
#All other animals normal



#One sample t-test
#Lest check if valence rating of cats differs from population mean of all animals (540)

mean(Valence.rating[Animal=="cat"])

#Yes, but is the difference significant?
t.test(Valence.rating[Animal=="cat"],mu=540)
#Yup.
#In a report we would write
# "Valence ratings for cats (M=744.8) were significantly above population mean (M=540.0), t(19)=7.26,p<.001"

#Independent samples t-test
#Next, lets check whether people think moose are more pleasant than cows
mean(Valence.rating[Animal=="cow"])
mean(Valence.rating[Animal=="moose"])

#Yes, but is the difference significant?
#We add var.equal=T to use pooled variance to estimate variance, if you leave this out R will perform Welch T-test instead.
t.test(Valence.rating[Animal=="moose"],Valence.rating[Animal=="cow"],var.equal=T)
#Nope.
#Let's visualize the results.
boxplot(Valence.rating[Animal=="moose"],Valence.rating[Animal=="cow"])
#In a report we would write "There were no significant differences between Valence ratings to cows and moose,
# t(38)=.11, p=.916" <-no need to report the means since the difference is not significant.


#Paired samples t-test
#Next, lets see whether people give different ratings for disgust and fearfulness
#of sharks
# first normality tests again:
shapiro.test(Disgust.rating[Animal=="shark"])
shapiro.test(Fear.rating[Animal=="shark"])

#Then have a look at the means...
mean(Disgust.rating[Animal=="shark"])
mean(Fear.rating[Animal=="shark"])
#Yes, but is it significant? 

#Then the t-test, this time both raings come from the same participant, so we're using the paired t-test!
t.test(Disgust.rating[Animal=="shark"],Fear.rating[Animal=="shark"],paired=T)
#Report: For sharks, fear ratings were significantly higher than disgust ratings (Mfear = 733,1; Mdisgust = 149.7)
# t(19)=25.9,p<.001
# You can omit the negative sign from the t-value, it tells the direction of the difference (which we knew from the means already)
# and does not affect significance.

#Exercises

#Q1 Are arousal ratings for tigers significantly different from population mean? Tip: You can estimate
#population mean for arousal from whole sample mean.
shapiro.test(Arousal.rating[Animal=="tiger"])
#Normal, barely within limits.
mean(Arousal.rating[Animal=="tiger"])
#Estimate population mean for Arousal rating of tigers from whole sample mean
mean(Arousal.rating)
#Small difference. Is it significant?
t.test(Arousal.rating[Animal=="tiger"],mu=mean(Arousal.rating))
#Nope!
#Tiger arousal ratings did not differ significantly from whole sample mean, t(19)=1.67,p=.111

#Q2 Are sharks more frightening than spiders?
mean(Fear.rating[Animal=="shark"])
mean(Fear.rating[Animal=="spider"])
#Looks like it...
shapiro.test(Fear.rating[Animal=="shark"])
shapiro.test(Fear.rating[Animal=="spider"])
t.test(Fear.rating[Animal=="shark"],Fear.rating[Animal=="spider"],var.equal=T)
#Yes!
#Q3 Do the arousal and valence ratings for pelicans differ from each other?
#Repeated measures test this time
mean(Arousal.rating[Animal=="pelican"])
mean(Valence.rating[Animal=="pelican"])
shapiro.test(Arousal.rating[Animal=="pelican"])
shapiro.test(Valence.rating[Animal=="pelican"])
t.test(Arousal.rating[Animal=="pelican"],Valence.rating[Animal=="pelican"],paired=T)
#Yes
#Q4 Are large animals more pleasant than small ones?
mean(Valence.rating[Size==1])
mean(Valence.rating[Size==3])
t.test(Valence.rating[Size==1],Valence.rating[Size==3],var.equal=T)
#Yes!
#Q5 Are dangerous animals more frightening than non-dangerous ones?
mean(Fear.rating[Dangerous==1])
mean(Fear.rating[Dangerous==0])
t.test(Fear.rating[Dangerous==1],Fear.rating[Dangerous==0],var.equal=T)
#Q6 Are the samples that are compared in Q4 and Q5 normally distributed? Are the analyses in Q4-5 justified?
shapiro.test(Valence.rating[Size==1])
shapiro.test(Valence.rating[Size==3])
shapiro.test(Fear.rating[Dangerous==1])
shapiro.test(Fear.rating[Dangerous==0])
#Normal only for dangerous animals, others non-normal, analyses clearly not justified! 
#Point here is that R will perform the test just fine regardless of whether the samples are normal or not, you have to check!

#Q7 You may have noticed that independent and paired samples t-test give different degrees of freedom (38 vs. 19)
# even though both have the same sample size (20+20). Why?
# They are calculated differently. Paired samples t-test is actually as a one sample t-test performed on the 
# difference scores of the paired observations which are compared to 0. Since number of 
# difference scores is 20, df for the paired t-test is 20-1.


#One-way ANOVA
#Do valence ratings vary between small, medium and large animals?
A1<-aov(Valence.rating~Size)
summary(A1)
#Yes they do. Visualize results
boxplot(Valence.rating~Size,xlab="Size", ylab="Valence rating")
#Get diagnostic plots
layout(matrix(c(1,2,3,4),2,2))
plot(A1)
#In a report we would write
# "A one-way between-subjects ANOVA showed that there was a significant effect of animals size (3 levels: small,medium, large)
# on valence ratings, F(2,237)=7.42,p<.001" 

#ANOVA assumptions
#test for homogeneity of variances:
install.packages('car')
library('car')
leveneTest(Valence.rating~Size)
bartlett.test(Valence.rating~Size)
#Variences not equal!!

#Visualize results
#Tää paketti ei toimi uusimmalla R studiolla!!
install.packages('gplots')
library('gplots')
plotmeans(Valence.rating~Size)
###^^^glopts not available for R 2.15.2 tarvii tarkistaa toimiiko mikroluokan koneilla
#We still don't know how they differ, for that we need to conduct pairwise tests
t.test(Valence.rating[Size==1],Valence.rating[Size==2],var.equal=T)
#Yes
t.test(Valence.rating[Size==1],Valence.rating[Size==3],var.equal=T)
#Yes
t.test(Valence.rating[Size==2],Valence.rating[Size==3],var.equal=T)
#No
#This would suggest that small animals are more unpleasant than large or medium animals,
#but no difference between medium and large animals.

#Q8 Do arousal ratings vary between small, medium and large animals?
B1<-aov(Arousal.rating~Size)
summary(B1)
#No differences
#No need to conduct pairwise comparisons because main effect not significant
#Let's visualize
boxplot(Arousal.rating~Size,xlab="Size", ylab="Valence rating")

#Q9 Does the homogeneity of variances assumpion hold for this model?
leveneTest(Arousal.rating~Size)
bartlett.test(Arousal.rating~Size)

#All is not lost if the assumptions don't hold! We will discuss ways to get around this problem at the end of the exercises.

#Two-way between-subject ANOVA
A2 <- aov(Valence.rating ~ Size*Dangerous)
summary(A2)
model.tables(A2, "means")
layout(matrix(c(1,2,3,4),2,2))
plot(A2)
# Main effect of Size
# Main effect of Dangerous
# Interaction of Dangerous * Size

#In a report we would write
# A 2 (Dangerous: Yes vs. No) X 3 (Size: small vs. medioum vs. large) between-subjects ANOVA on valence ratings
# produced main effects of Dangerous, F(1,234)=16.70,p<.001, and Size, F(1,237)=242.13,p<.001,
# which were modified by an interaction of Dangerous X Size, F(2,234)=28.66,p<.001.

#Visualisointi
boxplot(Valence.rating ~ Size*Dangerous, col=c("green", "grey"))	# not very clear..

interaction.plot(Size,Dangerous,Valence.rating, type="b", col=c(1:3),
                 leg.bty="o", leg.bg="beige", lwd=2, pch=c(18,24,22), 
                 xlab="Size", ylab="Valence rating", main="Interaction plot")

library(car)
Anova(A2, type=3)
# Let's decompose the interaction and conduct separate One-way anovas for Size separately
# to each subgroup (level) of Dangerous

DD<-animals[Dangerous==1,]
ND<-animals[Dangerous==0,]
A3<-aov(DD$Valence.rating~DD$Size)
A4<-aov(ND$Valence.rating~ND$Size)
summary(A3)
summary(A4)
#Size affects valence ratings, but only if the animal is dangerous!!!
# In a report we would write "To decompose the interaction, we conducted separate one-way ANOVAs for dangerous
# and non-dangerous animals. The ANOVA on non-dangerous animals was not significant, F=.93, whereas the 
# ANOVA on dangerous animals revealed a significant effect of size, F(2,117)=40.22,p<.001.

#Next, let's do all possible t-test within the the dangerous animals 
#group to find out where the difference comes from
#small-medium; medium-large; small-large
t.test(DD$Valence.rating[DD$Size==1],DD$Valence.rating[DD$Size==2],var.equal=T)
#Significant!
t.test(DD$Valence.rating[DD$Size==1],DD$Valence.rating[DD$Size==3],var.equal=T)
#Significant!
t.test(DD$Valence.rating[DD$Size==2],DD$Valence.rating[DD$Size==3],var.equal=T)
#Not significant!
# We found out that small dangerous animals are more unpleasant than medium OR large dangerous animals,
# But there are no differences in unpleasantness between medium and large dangerous animals.
# Doing these comparisons in the not dangerous group is not justified, because the main effect of Size was not 
# significant in that group. -> We can just conclude that for non-dangerous animals size does not affect
# valence ratings. The would be reported as for the example reports for t-tests above.

#Q10 Conduct a 2 (Dangerous: Yes vs. no) X 3 (Size: small vs. medium vs. large) ANOVA for Arousal ratings
# Decompose interactions and conduct pairwise post-hoc comparisons as appropriate
C1 <- aov(Arousal.rating ~ Size*Dangerous)
summary(C1)

#Size is not significant
#Dangerous is significant
#Size*Dangerous is significant

model.tables(C1, "means")
layout(matrix(c(1,2,3,4),2,2))
plot(C1)

#Let's visualize
interaction.plot(Size,Dangerous,Arousal.rating, type="b", col=c(1:3),
                 leg.bty="o", leg.bg="beige", lwd=2, pch=c(18,24,22), 
                 xlab="Size", ylab="Arousal rating", main="Interaction plot")

#It looks like there might be a difference of size between small animals and the others, but the direction
#of the difference is different for dangerous vs non-dangerous animals.

#Lets decompose and see...
C3<-aov(DD$Arousal.rating~DD$Size)
C4<-aov(ND$Arousal.rating~ND$Size)
summary(C3)
summary(C4)

#Now size is significant in both ANOVAs. Let's do post hoc tests to (3 pairwise comparisons to find out
#what differences are significant
t.test(DD$Arousal.rating[DD$Size==1],DD$Arousal.rating[DD$Size==2],var.equal=T)
#Significant!
t.test(DD$Arousal.rating[DD$Size==1],DD$Arousal.rating[DD$Size==3],var.equal=T)
#not significant
t.test(DD$Arousal.rating[DD$Size==2],DD$Arousal.rating[DD$Size==3],var.equal=T)
#not significant

#So in the dangerous group, only the difference between small and medium animals is significant.
#Let's check the non-dangerous group too.
t.test(ND$Arousal.rating[DD$Size==1],ND$Arousal.rating[DD$Size==2],var.equal=T)
#Significant!
t.test(ND$Arousal.rating[DD$Size==1],ND$Arousal.rating[DD$Size==3],var.equal=T)
#Significant!
t.test(ND$Arousal.rating[DD$Size==2],ND$Arousal.rating[DD$Size==3],var.equal=T)
#not significant
# In the non-dangerous group Arousal ratings to small animals were significantly different from
# medium and large animals, but no difference between medium and large animals.

#Bonus method: What to do when normality/sphericity assumptions don't hold in ANOVA?
#
#1. If you data is skewed, you can apply a log transformation to your data to make it more normal, do the analyses, then back-transform to the original data
# and report descriptives. If you do this, remeber that you can not report descripive values of the log-transformed data, as they do not directly represent
# real-world qualities of the sample. You would only report the statistical test results + notion that a log transform was made.
# all decriptives would come from the non-transformed data.

#2. You can apply a correction to the degrees of freedom to compensate for the lack of sphericity. This will lower the degrees of freedom, and 
# correspondingly the critical F-values for significance will become higher. As results, the p-value will go up, and may no longer be significant.
# This prevents you from getting false positives because of non-sphericity. If p is still significant, you can assume that the results is real and
# not a result of non-sphericity. Note!! The F-values you obtain from the test do not change, only the level that these values must reach for significance
# is altered!!!!
#
# How is this done? A critical statistic here is Epsilon(e). Think of it as a measure of how bad your data is in terms of sphericity. 
# Epsilon 1 means that the condition of sphericity is exactly met - perfect! no need for corrections!. The further epsilon decreases below
# 1, the greater the violation of sphericity. To compensate, you simply multiply your degrees of freedom with epsilon, and then check whether your
# result is still significant with the corrected degrees of freedom. 

#To do this, you have to first estimate what epsilon is. There are three ways to do this that are commonly used: Greenhouse-Geisser,
#Huynd-Feldt and Lower Bound estimates/corrections. They all give slightly different estimates for epsilon. Lower Bound is most conservative and 
#not reccommended. Use Huyndt-Feldt or Greenhouse-Geisser.

#We will not go through how to do this in R, as it is outside the scope of this course. It is sufficient that you know
# That you do not have to throw away your data of switch to nonparametric tests if the ANOVa assumptions are not met.


# Correct APA style reporting of statistics is required in homework reports!


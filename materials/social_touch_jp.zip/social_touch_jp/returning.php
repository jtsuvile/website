<?php
include_once('settings.php');
include_once('lib.php');

include('header.php');
    session_unset();
    ?>
<div id ="header">
<div style="top:0px;float:right;margin-right:10px;color:#ccc"><a href="admin/index.php">Admin</a></div>
<h1><?php echo $pagetexts['return1']; ?></h1>
</div>

<div id="container">
<?php

$login1=$pagetexts['login1'];
$login2=$pagetexts['login2'];

$register=$pagetexts['register'];
?>
<div id="intro">
<b><?php echo $pagetexts['return4'];?></b>
<form id="intro" method="GET" action="session.php">

<?php echo $pagetexts['return2'];?><br>

<input style="font-size:12px;" name="userID" type="text" onclick="this.value=''" value="<?php echo $login2;?>"> </p>
</form>
<p><br><br>
<b><?php echo $pagetexts['return5'];?></b>
<form id="intro" method="GET" action="session.php">
<?php echo $pagetexts['return3'];?><br>
<input style="font-size:12px;" name="userID" type="text" onclick="this.value=''" value="<?php echo $login2;?>"> </p>
</form>
</p>
</div>

<?php
include('footer.php');
?>

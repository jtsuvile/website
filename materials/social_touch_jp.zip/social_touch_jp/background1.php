<?php
include_once('lib.php');
include_once('settings.php');
include('header.php');

    if(array_key_exists('err',$_GET))
	$err=$_GET['err'];
    $userID=$_GET['userID'];
    $presentation=loadTxt("./subjects/$userID/presentation.txt",0);
    $sel_text = $pagetexts['select'];
    
    $keys=array('rel', 'kid','mom','dad','sis','bro','niece', 'nephew','aunt','uncle', 'f_cousin','m_cousin','f_friend', 'm_friend', 'f_contact', 'm_contact', 'f_toddler', 'm_toddler', 'r_f','r_m', 'r_f_tod', 'r_m_tod');
    
    if(isset($err))
    {
        $loc = $keys[$err];
        $msg=$pagetexts['bg_err'].' '.$pagetexts[$loc];
        $errormsg="<br><div class=\"error\">$msg</div><br><br>";
    }
    
?>
<div id="header">
<h1><?php echo $pagetexts['bg_1_title'];?></h1></div>
<div id="container">
<div style="padding-left:10px">
<?php $width = 350;?>
<style>
td{
    padding:10px;
    }
input{
    margin-right:3px;
    }
</style>
<br>
<div style="font-size:18px;"><?php echo $pagetexts['bg_1_text'];?></font></div>
<br>
<?php if(isset($errormsg)) echo $errormsg; ?>

<form method="POST" action="bg_check_1.php">
<input type="hidden" name="userID" value="<?php echo $userID; ?>" />
<table>

    <tr style="background:#ccc">
        <th style="width:100px"><?php echo $pagetexts['bg_pers'];?></th>
        <th style="width:250px"><?php echo $pagetexts['bg_age'];?></th>
        <th style="width:250px" colspan=2><?php echo $pagetexts['bg_lapse'];?></th>
        <th><?php echo $pagetexts['rp_sex'];?></th>
    </tr>

<?php
    $n = 1;
    for($i = 0; $i <= count($presentation)-6; $i++) {
        if($n%2==0){ ?> <tr style="background:#ccc">
<?php ;} else { ?> <tr style="background:#eee"> <?php ;}
    $term = $keys[$presentation[$i]];
    $lapse = $term.'_lapse';
    $lapse_scale = $term.'_lapse_scale';
    $age = $term.'_age';
    $sex = $term.'_sex';
    
    ?>
        <td style="width:150px"><?php echo $pagetexts[$term];?></td>
        
        <td> <select class="mySelect" name=<?php echo $age ?>>
        <?php
            for($m=-1;$m<100;$m++){
                $str="";
                if(isset($_SESSION[$age])&&$m==$_SESSION[$age]) $str=" SELECTED ";
                if($m==-1 && !isset($_SESSION[$age])) $str=" SELECTED ";
                if($m==-1){
                    echo "<option value=\"$m\"  $str>$sel_text</option>"; 
                } else {
                    echo "<option value=\"$m\"  $str>$m</option>";  
            }
            }
        ?>
        </select> 
            <?php echo $pagetexts['lapse_years_old'];?></td><td>
        <select class="mySelect" name=<?php echo $lapse?>>
        <?php
            for($k=-1;$k<12;$k++){
                $str="";
                if(isset($_SESSION[$lapse])&&$k==$_SESSION[$lapse]) $str=" SELECTED ";
                if($k==-1 && !isset($_SESSION[$lapse])) $str=" SELECTED ";
                if($k==-1){
                    echo "<option value=\"$k\"  $str>$sel_text</option>"; 
                } else if ($k<11){
                    echo "<option value=\"$k\"  $str>$k</option>";  
            	}
            	  else {
            		echo "<option value=\">10\">>10</option>";
            	}

            }?>
        </select> 
        </td><td style="width:100px">
<input type="radio" name=<?php echo $lapse_scale ;?> value="1" <?php if(isset($_SESSION[$lapse_scale])&&$_SESSION[$lapse_scale]==="1"){?>checked="checked"<?php }?>><?php echo $pagetexts['lapse_d'];?><br>
<input type="radio" name=<?php echo $lapse_scale ;?> value="2" <?php if(isset($_SESSION[$lapse_scale])&&$_SESSION[$lapse_scale]==="2"){?>checked="checked"<?php }?>><?php echo $pagetexts['lapse_w'];?><br>
<input type="radio" name=<?php echo $lapse_scale ;?> value="3" <?php if(isset($_SESSION[$lapse_scale])&&$_SESSION[$lapse_scale]==="3"){?>checked="checked"<?php }?>><?php echo $pagetexts['lapse_m'];?><br>
<input type="radio" name=<?php echo $lapse_scale;?> value="4" <?php if(isset($_SESSION[$lapse_scale])&&$_SESSION[$lapse_scale]==="4"){?>checked="checked"<?php }?>><?php echo $pagetexts['lapse_y'];?><br>
        </td>
        <td>
<?php if($term=='rel' || $term=='kid'){
    $sex = $term.'_sex';
    ?>
<input type="radio" name=<?php echo $sex ;?> value="1" <?php if(isset($_SESSION[$sex])&&$_SESSION[$sex]==="1"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_male'];?>&nbsp;&nbsp;&nbsp;&nbsp;<br>
<input type="radio" name=<?php echo $sex ;?> value="0" <?php if(isset($_SESSION[$sex])&&$_SESSION[$sex]==="0"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_female'];?>
<?php ;} else {?>
            <input type="hidden" name=<?php echo $sex ?> value="-1">
<?php ;}?>
        </td>
    </tr>
    
<?php $n = $n+1;
    }
    
    if(count($keys)-count($presentation) > 0){
        for($j=0; $j < count($keys); $j++) {
            if(!(in_array($j, $presentation)) OR $j>=16){
                $term = $keys[$j];
                $age = $term.'_age';
                $lapse = $term.'_lapse';
                $lapse_scale = $term.'_lapse_scale';
                $sex = $term.'_sex'?>
        <input type="hidden" name=<?php echo $age ?> value="-100">
        <input type="hidden" name=<?php echo $lapse ?> value="-100">
        <input type="hidden" name=<?php echo $lapse_scale ?> value="-100">
        <input type="hidden" name=<?php echo $sex ?> value="-100">
<?php
    }
    }
    } else {
        for($j=count($keys)-4; $j <= count($keys); $j++) {
            if(!(in_array($j, $presentation)) OR $j>=16){
                $term = $keys[$j];
                $age = $term.'_age';
                $lapse = $term.'_lapse';
                $lapse_scale = $term.'_lapse_scale';
                $sex = $term.'_sex'?>
    <input type="hidden" name=<?php echo $age ?> value="-100">
    <input type="hidden" name=<?php echo $lapse ?> value="-100">
    <input type="hidden" name=<?php echo $lapse_scale ?> value="-100">
    <input type="hidden" name=<?php echo $sex ?> value="-100">
<?php
    }
    }
    }
    ?>

</table>
<button id="navigationbutton" onclick="history.go(-1);"><?php echo $pagetexts['back'];?>  </button>
<input id="navigationbutton" type="submit" value="<?php echo $pagetexts['forward'];?>" style="float:right;margin-right:50px;">
</form>

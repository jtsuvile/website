<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta name="viewport" content="user-scalable=no">
		<title><?php echo $pagetexts['title']; ?></title>
		<meta http-equiv="Content-type" content="text/html;charset=UTF-8">
		<LINK href="css/main.css" rel="stylesheet" type="text/css">

		<script type="text/javascript" src="http://code.jquery.com/jquery-1.5.js"></script>
		<script type="text/javascript" src="js/common.js"></script> 
		<script type="text/javascript" src="js/99.js"></script> 
		 <script type="text/javascript" src="js/pain.js"></script> 
		 <!--<script type="text/javascript" src="js/pain_touch.js"></script>  -->
		 <script type="text/javascript" src="js/touch_handler.js"></script>
		<script type='application/javascript' src='js/fastclick.js'></script> 
		
		<style type="text/css">

		body{
		-webkit-user-select: none;
		-khtml-user-select: none;
		-moz-user-select: none;
		-o-user-select: none;
		user-select: none;
		}

		*{
		-webkit-user-select: none;
		-khtml-user-select: none;
		-moz-user-select: none;
		-o-user-select: none;
		user-select: none;
		}
		</style>
	</head>
<body>


<?php
    include('lib.php');
    session_start();
    $userID=$_POST['userID'];
    
    $age="age:";
    $lapse="lapse:";
    $lapse_scale="lapse_scale:";
    $sex="sex:";
    
    // check that we have all variables
    $keys=array('rel', 'kid','mom','dad','sis','bro','niece', 'nephew', 'aunt','uncle','f_cousin','m_cousin','f_friend','m_friend', 'f_contact', 'm_contact',  'r_f','r_m', 'r_f_tod', 'r_m_tod');
    $presentation=loadTxt("./subjects/$userID/presentation.txt",0);
    
    for($k=0;$k<count($keys);$k++){
        $name1 = $keys[$k].'_age';
        $name2 = $keys[$k].'_lapse';
        $name4 = $keys[$k].'_lapse_scale';
        $name3 = $keys[$k].'_sex';
        if(isset($_POST[$name1]))
        {
            $_SESSION[$name1]=$_POST[$name1];
        }
        if(isset($_POST[$name2]))
        {
            $_SESSION[$name2]=$_POST[$name2];
        }
        if(isset($_POST[$name3]))
        {
            $_SESSION[$name3]=$_POST[$name3];
        }
        if(isset($_POST[$name4]))
        {
            $_SESSION[$name4]=$_POST[$name4];
        }
    }
    
    $err=-1;
    
    for($k=0;$k<count($keys);$k++){
        $name1 = $keys[$k].'_age';
        $name2 = $keys[$k].'_lapse';
        $name4 = $keys[$k].'_lapse_scale';
        $name3 = $keys[$k].'_sex'; 
		if(!array_key_exists($name1,$_POST) || !array_key_exists($name2,$_POST) || !array_key_exists($name3,$_POST) || !array_key_exists($name4,$_POST) || $_POST[$name1] === '-1' || $_POST[$name2] === '-1' || $_POST[$name1] === '' || $_POST[$name2] === ''|| $_POST[$name4] === NULL|| $_POST[$name3] === NULL)
        { 
            $err=$k;
            break;
        }
        else
        {
            $age.=$_POST[$name1].",";
            $lapse.=$_POST[$name2].",";
            $lapse_scale.=$_POST[$name4].",";
            $sex.=$_POST[$name3].",";
        }
    }
    
    if($err>=0)
    {
        header("Location: background1.php?err=$err&userID=$userID");
    }
    else
    {
        $age.=PHP_EOL;
        $lapse.=PHP_EOL;
        $lapse_scale.=PHP_EOL;
        $sex.=PHP_EOL;
        
        $file="subjects/$userID/background1.txt";
        $fh = fopen($file, 'a') or die("There was a disk error. Please email juulia.suvilehto@aalto.fi");
        fwrite($fh, $age);
        fwrite($fh, $lapse);
        fwrite($fh, $lapse_scale);
        fwrite($fh, $sex);
        fclose($fh);
        
        
        header("Location: background2.php?userID=$userID");
    }
    ?>

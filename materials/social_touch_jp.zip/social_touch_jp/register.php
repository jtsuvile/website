<?php
include_once('lib.php');
include_once('settings.php');
include('header.php');

if(array_key_exists('err',$_GET))
	$err=$_GET['err'];
    $userID=$_GET['userID'];


if(isset($err))
{
    switch($err){    
        case 0:
            $msg=$pagetexts['rp_sex_err'];
            break;
        case 1:
            $msg=$pagetexts['rp_age_err'];
            break;
        case 2:
            $msg=$pagetexts['rp_weight_err'];
            break;
        case 3:
            $msg=$pagetexts['rp_height_err'];
            break;
        case 4:
            $msg=$pagetexts['rp_handedness_err'];
            break;
        case 5:
            $msg=$pagetexts['rp_education_err'];
            break;
	case 6:
	    $msg=$pagetexts['rp_ps1_err'];
	    break;
	case 7:
	    $msg=$pagetexts['rp_ps2_err'];
	    break;
	case 8:
	    $msg=$pagetexts['rp_ps3_err'];
	    break;
	case 9:
		$msg=$pagetexts['cu_interest_err'];
	    break;

    }
    $errormsg="<br><div class=\"error\">$msg</div><br><br>";
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">

<html>
<head>
<title><?php echo $pagetexts['title']; ?></title>
<LINK href="css/main.css" rel="stylesheet" type="text/css">
<meta http-equiv="Content-type" content="text/html;charset=UTF-8">
</head>
<body onload="checkDisable();">

<div id="header">
<h1><?php echo $pagetexts['rp_title'];?></h1></div>
<div id="container">
<div style="padding-left:10px">
<style>
td{
    padding:10px;
    }
input{
    margin-right:3px;
    }
</style>
<br>
<div style="font-size:18px;"><?php echo $pagetexts['rp_text'];?></div>
<br>
<?php if(isset($errormsg)) echo $errormsg; ?>
<form method="POST" action="addme.php">
<input type="hidden" name="userID" value="<?php echo $userID; ?>" />
<table>
    <tr style="background:#ccc">
        <td style="width:200px"><?php echo $pagetexts['rp_sex'];?></td>
        <td>
<input type="radio" name="sex" value="0" <?php if(isset($_SESSION['sex'])&&$_SESSION['sex']==="0"){?>checked="checked"<?php }?> > <?php echo $pagetexts['rp_male'];?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="sex" value="1" <?php if(isset($_SESSION['sex'])&&$_SESSION['sex']==="1"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_female'];?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="sex" value="5" <?php if(isset($_SESSION['sex'])&&$_SESSION['sex']==="5"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_na'];?>
        </td>
    </tr>
    <tr style="background:#eee">
        <td style="width:200px"><?php echo $pagetexts['rp_age'];?></td>
        <td>
            <select name="age">
            <?php
                for($i=0;$i<100;$i++){
                    $str="";
                    if(isset($_SESSION['age'])&&$i==$_SESSION['age']) $str=" SELECTED ";
                    if($i==18 && !isset($_SESSION['age'])) $str=" SELECTED ";
                    echo "<option value=\"$i\"  $str>$i</option>";  
                }
            ?>
            </select> 
        </td>
    </tr>
    <tr style="background:#ccc">
        <td style="width:200px"><?php echo $pagetexts['rp_weight'];?></td>
        <td>
            <select class="mySelect" id="weight" name="weight">
            <?php
                for($i=0;$i<200;$i++){
                    $str="";
                    if(isset($_SESSION['weight'])&&$i==$_SESSION['weight']) $str=" SELECTED ";
                    if($i==70 && !isset($_SESSION['weight'])) $str=" SELECTED ";

                    echo "<option value=\"$i\"  $str>$i</option>";  
                }
            ?>
            </select> <?php echo $pagetexts['rp_kg'];?><br>
        </td>
    </tr>
    <tr style="background:#eee">
        <td style="width:200px"><?php echo $pagetexts['rp_height'];?></td>
        <td>
            <select class="mySelect" id="height" name="height">
            <?php
                for($i=0;$i<300;$i++){
                    $str="";
                    if(isset($_SESSION['height'])&&$i==$_SESSION['height']) $str=" SELECTED ";
                    if($i==170 && !isset($_SESSION['height'])) $str=" SELECTED ";
                    echo "<option value=\"$i\"  $str>$i</option>";  
                }
            ?></select>
             <?php echo $pagetexts['rp_cm'];?><br>
        </td>
    </tr>
    <tr style="background:#ccc">
        <td style="width:200px"><?php echo $pagetexts['rp_handedness'];?></td>
        <td>
            <input type="radio" name="hand" value="0"<?php if(isset($_SESSION['hand'])&&$_SESSION['hand']==="0"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_left'];?>&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="radio" name="hand" value="1"<?php if(isset($_SESSION['hand'])&&$_SESSION['hand']==="1"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_right'];?>
        </td>
    </tr>
    <tr style="background:#eee">
        <td style="width:200px"><?php echo $pagetexts['rp_education'];?></td>
        <td>
<input type="radio" name="education" value="0" <?php if(isset($_SESSION['education'])&&$_SESSION['education']==="0"){?>checked="checked"<?php };?>><?php echo $pagetexts['rp_edu1'];?> &nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="education" value="1" <?php if(isset($_SESSION['education'])&&$_SESSION['education']==="1"){?>checked="checked"<?php };?>><?php echo $pagetexts['rp_edu2'];?> &nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="education" value="2" <?php if(isset($_SESSION['education'])&&$_SESSION['education']==="2"){?>checked="checked"<?php };?> ><?php echo $pagetexts['rp_edu3'];?> &nbsp;&nbsp;&nbsp;&nbsp;
        </td>
    </tr>
    <tr style="background:#ccc">
        <td style="width:200px"><?php echo $pagetexts['rp_ps1'];?></td>
        <td>
            <input type="radio" name="psychologist" value="0"<?php if(isset($_SESSION['psychologist'])&&$_SESSION['psychologist']==="0"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_n'];?>  &nbsp;&nbsp;&nbsp;&nbsp;
            <input type="radio" name="psychologist" value="1"<?php if(isset($_SESSION['psychologist'])&&$_SESSION['psychologist']==="1"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_y'];?> &nbsp;&nbsp;&nbsp;&nbsp;
        </td>
    </tr>
    <tr style="background:#eee">
        <td style="width:200px"><?php echo $pagetexts['rp_ps2'];?></td>
        <td>
            <input type="radio" name="psychiatrist" value="0"<?php if(isset($_SESSION['psychiatrist'])&&$_SESSION['psychiatrist']==="0"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_n'];?> &nbsp;&nbsp;&nbsp;&nbsp;
            <input type="radio" name="psychiatrist" value="1"<?php if(isset($_SESSION['psychiatrist'])&&$_SESSION['psychiatrist']==="1"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_y'];?> &nbsp;&nbsp;&nbsp;&nbsp;
        </td>
    </tr>
    <tr style="background:#ccc">
        <td style="width:200px"><?php echo $pagetexts['rp_ps3'];?></td>
        <td>
            <input type="radio" name="neurologist" value="0"<?php if(isset($_SESSION['neurologist'])&&$_SESSION['neurologist']==="0"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_n'];?> &nbsp;&nbsp;&nbsp;&nbsp;
            <input type="radio" name="neurologist" value="1"<?php if(isset($_SESSION['neurologist'])&& $_SESSION['neurologist']==="1"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_y'];?> &nbsp;&nbsp;&nbsp;&nbsp;
        </td>
    </tr>
    <tr style="background:#eee">
        <td style="width:200px"><?php echo $pagetexts['cu_preference'];?></td>
        <td>
<input type="radio" name="cu_preference" value="0" <?php if(isset($_SESSION['cu_preference'])&&$_SESSION['cu_preference']==="0"){?>checked="checked"<?php }?> > <?php echo $pagetexts['rp_male'];?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="cu_preference" value="1" <?php if(isset($_SESSION['cu_preference'])&&$_SESSION['cu_preference']==="1"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_female'];?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="cu_preference" value="2" <?php if(isset($_SESSION['cu_preference'])&&$_SESSION['cu_preference']==="2"){?>checked="checked"<?php }?>><?php echo $pagetexts['cu_both'];?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="cu_preference" value="3" <?php if(isset($_SESSION['cu_preference'])&&$_SESSION['cu_preference']==="3"){?>checked="checked"<?php }?>><?php echo $pagetexts['cu_neither'];?>&nbsp;&nbsp;&nbsp;&nbsp;

        </td>
    </tr>   
</table>
<button id="navigationbutton" style="visibility:hidden" onclick="history.go(-1);">Back </button>
<input id="navigationbutton" type="submit" value="<?php echo $pagetexts['rp_title'];?>" style="float:right;margin-right:50px;">

</form>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<?php session_start(); ?>
<html>
	<head>
		<title><?php echo $pagetexts['title']; ?></title>
		<LINK href="css/main.css" rel="stylesheet" type="text/css">
		<meta http-equiv="Content-type" content="text/html;charset=UTF-8">

                <script type="text/javascript" src="js/confirmAction.js"></script> 

	</head>
		<body>

<?php
    include('lib.php');
        session_start();
    $userID=$_POST['userID'];
    
    $data="pleasant:";
    
// check that we have all variables
    $keys=array('rel', 'kid','mom','dad','sis','bro','niece', 'nephew',  'aunt','uncle', 'f_cousin','m_cousin', 'f_friend', 'm_friend', 'f_contact', 'm_contact', 'r_f','r_m', 'r_f_tod', 'r_m_tod');
    $presentation=loadTxt("./subjects/$userID/presentation.txt",0);

    for($k=0;$k<count($keys);$k++){
        $name = $keys[$k].'_pleasant';
        if(isset($_POST[$name]))
        {
            $_SESSION[$name]=$_POST[$name];
        }
    }

$err=-1;
    
for($k=0;$k<count($keys);$k++){
    $name = $keys[$k].'_pleasant';
    if(!isset($_POST[$name]))
    {
        $err=$k;
        break;
    }
    else
    {
        $data.=$_POST[$name].",";
    }
}
        
if($err>=0)
{
        header("Location: background3.php?err=$err&userID=$userID");
}
else
{
$data.=PHP_EOL;

$file="subjects/$userID/background3.txt";
$fh = fopen($file, 'a') or die("There was a disk error. Please email juulia.suvilehto@aalto.fi");
fwrite($fh, $data);
fclose($fh);


header("Location: session.php?userID=$userID");
}
?>

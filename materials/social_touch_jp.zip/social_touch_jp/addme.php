<?php
include('lib.php');
    session_start();
    $userID=$_POST['userID'];
$data="";
// check that we have all variables
$keys=array('sex','age','weight','height','hand','education','psychologist','psychiatrist','neurologist','cu_preference');

$err=-1;
    
for($k=0;$k<count($keys);$k++){
    if(isset($_POST[$keys[$k]]))
    {
    $_SESSION[$keys[$k]]=$_POST[$keys[$k]];
    }
}
    
for($k=0;$k<count($keys);$k++){
    if(!isset($_POST[$keys[$k]]) OR strlen($_POST[$keys[$k]])==0)
    {
        $err=$k;
        break;
    }
    else
    {
        $data.=htmlspecialchars($_POST[$keys[$k]]).",";
    }
}
        
if($err>=0)
{
        header("Location: register.php?err=$err&userID=$userID");
}
else
{
if(!is_dir("subjects/$userID/")){
    system("mkdir subjects/$userID/",$ret);
}
system("chmod 777 subjects/$userID/",$ret);
if($ret!=0)
    die("There was a disk error. Please email juulia.suvilehto@aalto.fi");

system("cp subjects/index.php subjects/$userID/");
$file="subjects/$userID/register.txt";
$fh = fopen($file, 'a') or die("There was a disk error. Please email juulia.suvilehto@aalto.fi");
fwrite($fh, $data);
fclose($fh);
    
header("Location: cultural_background.php?userID=$userID");
}
?>

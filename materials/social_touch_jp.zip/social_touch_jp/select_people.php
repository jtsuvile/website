<?php
include_once('lib.php');
include_once('settings.php');
include('header.php');

if(array_key_exists('err',$_GET))
	$err=$_GET['err'];
    $userID=$_GET['userID'];

if(isset($err))
{
    switch($err){    
        case 0:
            $msg=$pagetexts['sp_rel_err'];
            break;
        case 1:
            $msg=$pagetexts['sp_kid_err'];
            break;
        case 2:
            $msg=$pagetexts['sp_mom_err'];
            break;
        case 3:
            $msg=$pagetexts['sp_dad_err'];
            break;
        case 4:
            $msg=$pagetexts['sp_sis_err'];
            break;
        case 5:
            $msg=$pagetexts['sp_bro_err'];
            break;
        case 6:
            $msg=$pagetexts['sp_niece_err'];
            break;
        case 7:
            $msg=$pagetexts['sp_nephew_err'];
            break;
        case 8:
            $msg=$pagetexts['sp_aunt_err'];
            break;
        case 9:
            $msg=$pagetexts['sp_uncle_err'];
            break;
        case 10:
            $msg=$pagetexts['sp_f_cousin_err'];
            break;
        case 11:
            $msg=$pagetexts['sp_m_cousin_err'];
            break;
        case 12:
            $msg=$pagetexts['sp_f_friend_err'];
            break;
        case 13:
            $msg=$pagetexts['sp_m_friend_err'];
            break;
        case 14:
            $msg=$pagetexts['sp_f_contact_err'];
            break;
        case 15:
            $msg=$pagetexts['sp_m_contact_err'];
            break;
    }
    $errormsg="<br><div class=\"error\">$msg</div><br><br>";
}

?>
<div id="header">
<h1><?php echo $pagetexts['sp_title'];?></h1></div>
<div id="container">
<div style="padding-left:10px">
<?php $width = 350;?>
<style>
td{
    padding:10px;
    }
input{
    margin-right:3px;
    }
</style>
<br>
<div style="font-size:18px;"><?php echo $pagetexts['sp_text'];?></font></div>
<br>
<?php if(isset($errormsg)) echo $errormsg; ?>

<form method="POST" action="addme2.php">
<input type="hidden" name="userID" value="<?php echo $userID; ?>" />
<table>
    <tr style="background:#ccc">
        <td style="width:<?php echo $width?>px"><?php echo $pagetexts['sp_relationship'];?></td>
        <td>
            <input type="radio" name="rel" value="3" <?php if(isset($_SESSION['rel'])&&$_SESSION['rel']==="3"){?>checked="checked"<?php }?>><?php echo $pagetexts['sp_relationship3'];?> &nbsp;&nbsp;&nbsp;&nbsp;<br>
            <input type="radio" name="rel" value="2" <?php if(isset($_SESSION['rel'])&&$_SESSION['rel']==="2"){?>checked="checked"<?php }?>><?php echo $pagetexts['sp_relationship2'];?> &nbsp;&nbsp;&nbsp;&nbsp;<br>
            <input type="radio" name="rel" value="1" <?php if(isset($_SESSION['rel'])&&$_SESSION['rel']==="1"){?>checked="checked"<?php }?>><?php echo $pagetexts['sp_relationship1'];?> &nbsp;&nbsp;&nbsp;&nbsp;<br>
            <input type="radio" name="rel" value="0" <?php if(isset($_SESSION['rel'])&&$_SESSION['rel']==="0"){?>checked="checked"<?php }?>><?php echo $pagetexts['sp_relationship0'];?> &nbsp;&nbsp;&nbsp;&nbsp;<br>
        </td>
    </tr>
    <tr style="background:#eee">
        <td style="width:200px"><?php echo $pagetexts['sp_child'].$pagetexts['sp_exists'];?></td>
        <td>
            <input type="radio" name="kid" value="1" <?php if(isset($_SESSION['kid'])&&$_SESSION['kid']==="1"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_y'];?>&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="radio" name="kid" value="0" <?php if(isset($_SESSION['kid'])&&$_SESSION['kid']==="0"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_n'];?>
        </td>
    </tr>

    <tr style="background:#ccc">
        <td style="width:200px"><?php echo $pagetexts['sp_alive1'].$pagetexts['sp_mother'].' '.$pagetexts['sp_alive2'];?></td>
        <td>
            <input type="radio" name="mom" value="1" <?php if(isset($_SESSION['mom'])&&$_SESSION['mom']==="1"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_y'];?>&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="radio" name="mom" value="0" <?php if(isset($_SESSION['mom'])&&$_SESSION['mom']==="0"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_n'];?>
        </td>
    </tr>
    <tr style="background:#eee">
        <td style="width:200px"><?php echo $pagetexts['sp_alive1'].$pagetexts['sp_father'].' '.$pagetexts['sp_alive2'];?></td>
        <td>
            <input type="radio" name="dad" value="1" <?php if(isset($_SESSION['dad'])&&$_SESSION['dad']==="1"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_y'];?>&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="radio" name="dad" value="0" <?php if(isset($_SESSION['dad'])&&$_SESSION['dad']==="0"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_n'];?>           
        </td>
    </tr>
    <tr style="background:#ccc">
        <td style="width:200px"><?php echo $pagetexts['sp_sister'].$pagetexts['sp_exists'];?></td>
        <td>
            <input type="radio" name="sis" value="1" <?php if(isset($_SESSION['sis'])&&$_SESSION['sis']==="1"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_y'];?>&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="radio" name="sis" value="0" <?php if(isset($_SESSION['sis'])&&$_SESSION['sis']==="0"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_n'];?>
        </td>
    </tr>
    <tr style="background:#eee">
        <td style="width:200px"><?php echo $pagetexts['sp_brother'].$pagetexts['sp_exists'];?></td>
        <td>
            <input type="radio" name="bro" value="1" <?php if(isset($_SESSION['bro'])&&$_SESSION['bro']==="1"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_y'];?>&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="radio" name="bro" value="0" <?php if(isset($_SESSION['bro'])&&$_SESSION['bro']==="0"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_n'];?>
        </td>
    </tr>
    <tr style="background:#ccc">
        <td style="width:200px"><?php echo $pagetexts['sp_niece'].$pagetexts['sp_exists'];?></td>
        <td>
            <input type="radio" name="niece" value="1"<?php if(isset($_SESSION['niece'])&&$_SESSION['niece']==="1"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_y'];?>&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="radio" name="niece" value="0"<?php if(isset($_SESSION['niece'])&&$_SESSION['niece']==="0"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_n'];?>
        </td>
    </tr>
    <tr style="background:#eee">
        <td style="width:200px"><?php echo $pagetexts['sp_nephew'].$pagetexts['sp_exists'];?></td>
        <td>
            <input type="radio" name="nephew" value="1"<?php if(isset($_SESSION['nephew'])&&$_SESSION['nephew']==="1"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_y'];?>&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="radio" name="nephew" value="0"<?php if(isset($_SESSION['nephew'])&&$_SESSION['nephew']==="0"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_n'];?>
        </td>
    </tr>
    <tr style="background:#ccc">
        <td style="width:200px"><?php echo $pagetexts['sp_aunt'].$pagetexts['sp_exists'];?></td>
        <td>
            <input type="radio" name="aunt" value="1"<?php if(isset($_SESSION['aunt'])&&$_SESSION['aunt']==="1"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_y'];?>&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="radio" name="aunt" value="0"<?php if(isset($_SESSION['aunt'])&& $_SESSION['aunt']==="0"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_n'];?>
        </td>
    </tr>
    <tr style="background:#eee">
        <td style="width:200px"><?php echo $pagetexts['sp_uncle'].$pagetexts['sp_exists'];?></td>
        <td>
            <input type="radio" name="uncle" value="1"<?php if(isset($_SESSION['uncle'])&&$_SESSION['uncle']==="1"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_y'];?>&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="radio" name="uncle" value="0"<?php if(isset($_SESSION['uncle'])&&$_SESSION['uncle']==="0"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_n'];?>
        </td>
    </tr>
    <tr style="background:#ccc">
        <td style="width:200px"><?php echo $pagetexts['sp_f_cousin'].$pagetexts['sp_exists'];?></td>
        <td>
            <input type="radio" name="f_cousin" value="1"<?php if(isset($_SESSION['f_cousin'])&&$_SESSION['f_cousin']==="1"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_y'];?>&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="radio" name="f_cousin" value="0"<?php if(isset($_SESSION['f_cousin'])&&$_SESSION['f_cousin']==="0"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_n'];?>
        </td>
    </tr>
    <tr style="background:#eee">
        <td style="width:200px"><?php echo $pagetexts['sp_m_cousin'].$pagetexts['sp_exists'];?></td>
        <td>
            <input type="radio" name="m_cousin" value="1"<?php if(isset($_SESSION['m_cousin'])&&$_SESSION['m_cousin']==="1"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_y'];?>&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="radio" name="m_cousin" value="0"<?php if(isset($_SESSION['m_cousin'])&&$_SESSION['m_cousin']==="0"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_n'];?>
        </td>
    </tr>
    <tr style="background:#ccc">
        <td style="width:200px"><?php echo $pagetexts['sp_f_friend'].$pagetexts['sp_exists'];?></td>
        <td>
            <input type="radio" name="f_friend" value="1"<?php if(isset($_SESSION['f_friend'])&&$_SESSION['f_friend']==="1"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_y'];?>&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="radio" name="f_friend" value="0"<?php if(isset($_SESSION['f_friend'])&&$_SESSION['f_friend']==="0"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_n'];?>
        </td>
    </tr>
    <tr style="background:#eee">
        <td style="width:200px"><?php echo $pagetexts['sp_m_friend'].$pagetexts['sp_exists'];?></td>
        <td>
            <input type="radio" name="m_friend" value="1"<?php if(isset($_SESSION['m_friend'])&&$_SESSION['m_friend']==="1"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_y'];?>&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="radio" name="m_friend" value="0"<?php if(isset($_SESSION['m_friend'])&&$_SESSION['m_friend']==="0"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_n'];?>
        </td>
    </tr>

    <tr style="background:#ccc">
        <td style="width:200px"><?php echo $pagetexts['sp_f_contact'].$pagetexts['sp_exists'];?></td>
        <td>
            <input type="radio" name="f_contact" value="1"<?php if(isset($_SESSION['f_contact'])&&$_SESSION['f_contact']==="1"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_y'];?>&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="radio" name="f_contact" value="0"<?php if(isset($_SESSION['f_contact'])&&$_SESSION['f_contact']==="0"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_n'];?>
        </td>
    </tr>
    <tr style="background:#eee">
        <td style="width:200px"><?php echo $pagetexts['sp_m_contact'].$pagetexts['sp_exists'];?></td>
        <td>
            <input type="radio" name="m_contact" value="1"<?php if(isset($_SESSION['m_contact'])&&$_SESSION['m_contact']==="1"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_y'];?>&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="radio" name="m_contact" value="0"<?php if(isset($_SESSION['m_contact'])&&$_SESSION['m_contact']==="0"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_n'];?>
        </td>
    </tr>




</table>
<button id="navigationbutton" onclick="history.go(-1);"><?php echo $pagetexts['back'];?> </button>
<input id="navigationbutton" type="submit" value="<?php echo $pagetexts['forward'];?>" style="float:right;margin-right:50px;">
</form>

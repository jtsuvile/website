 function toggleDisability(clicked_id, selectElement){
        var x = document.getElementById(clicked_id).checked;
	if (x==false)
	{
	document.getElementById(selectElement).disabled=false;
   	} 
	else if (x==true)
	{
	document.getElementById(selectElement).disabled=true;
	}
  }

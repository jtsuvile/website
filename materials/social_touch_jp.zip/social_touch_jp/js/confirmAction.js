function confirmAction(){
      var confirmed = confirm("この質問票に対する私の回答が、報告書および刊行物において匿名で使用されることがあることを理解しました。上記の調査に参加することに同意します。また、回答を続けることで、これに正式に同意することを確認します。");
      return confirmed;
}

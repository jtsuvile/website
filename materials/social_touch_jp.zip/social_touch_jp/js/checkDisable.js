 function checkDisable(){
    var z = document.getElementById('cntrl').checked;       
    if (z==false)
        {
        document.getElementById('conditi').disabled=false;
        document.getElementById('conditi2').disabled=false;
        document.getElementById('conditi3').disabled=false;
        }
    else 
        {
        document.getElementById('conditi').disabled=true;
        document.getElementById('conditi2').disabled=true;	
        document.getElementById('conditi3').disabled=true;	        
        } 
 }

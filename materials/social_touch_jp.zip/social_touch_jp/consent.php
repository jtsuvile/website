<?php
include_once('lib.php');
include_once('settings.php');
include('consentheader.php');

if(array_key_exists('err',$_GET))
	$err=$_GET['err'];

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">

<html>
<head>
<title><"Informed consent"></title>
<LINK href="css/main.css" rel="stylesheet" type="text/css">
<meta http-equiv="Content-type" content="text/html;charset=UTF-8">
</head>
<body>

<div id="header">
<h1><?php echo 'Informed consent';?></h1></div>
<div id="container">
<div style="padding-left:10px">
<style>
td{
    padding:10px;
    }
input{
    margin-right:3px;
    }
</style>
<br>

<?php if(isset($errormsg)) echo $errormsg; ?>
</td>
Please read the information below carefully and click ‘yes’ at the bottom of the page if you agree with the statements.
<br>
<br>
<div class="scrollabletextbox" name="consent">
<?php include('./ethics_oxford.htm');?>
</div>
<div>
<div style="float:right;margin-right:50px">
<form action="register.php">
<input type="submit" onclick="return confirmAction()" value="Yes">
</form>
</div>

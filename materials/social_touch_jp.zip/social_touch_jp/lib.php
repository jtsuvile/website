<?php
include('settings.php');
    
function makePresentation($pfpath){
    global $randomization;
    $foo = preg_replace("/presentation/", "select_people", $pfpath);
    $fh = fopen($foo, 'r') or die("There was a disk error. Please email juulia.suvilehto@aalto.fi");
    $new = fgets($fh);
    $new = explode(',',$new);
    $temp=array();
    $counter=0;
    for($c=0;$c<count($new);$c++)
    {
        $val = $new[$counter];
        if($val>=1)
            array_push($temp, $counter);
        $counter++;
    }
    fclose($fh);
    array_push($temp, 16, 17, 18, 19, 20);
    $pfh=fopen($pfpath,'w');     // presentation file handle
    foreach($temp as $line)
        fwrite($pfh,"$line\n");
    fclose($pfh);
}

function loadFolder($folder){
    $list=array();
    $allowed=array(
        "jpeg",
        "png",
        "gif",
        "jpg",
        "mp3",
        "flv",
        "JPEG",
        "PNG",
        "GIF",
        "JPG",
        "MP3",
        "FLV"
    );
    //List files in images directory
    $stat=exec("ls -t $folder",$files);
    foreach($files as $file)
    {
        if($file[0] == ".") continue;
        $temp=explode(".",$file);
        if(count($temp) == 2)
        {
            $extension=$temp[1];
            if(in_array($extension,$allowed))
                array_push($list,$file);
        }
    }
    return $list;
}

function loadTxt($file,$level){
    if(is_dir($file))
        return loadFolder($file);

    // the variable $level tells us if we have nested arrays, i.e. level 0 just a string, level 1 array split as |, level 2 array split as ,
    $fh=fopen($file,'r');
    if(!$fh)
	die("Invalid file ".$file);
    $list=array();
    while(!feof($fh)){   
    $line=trim(fgets($fh));
	if($line=="") continue;
        if($level==0)
            $out=$line;

        if($level>=1)
        {
            $arr=explode("|",$line);
            $out=$arr;
            if($level==2)
            {
                $tmparr=array();
                foreach($arr as $val)
                {
                    $subarr=explode(",",trim($val));
                    array_push($tmparr,$subarr);
                }
                $out=$tmparr;
            }
        }
        array_push($list,$out);
    }
    return $list;
}
    
    function loadPgTxt($file){
        if(is_dir($file))
            return loadFolder($file);
        $fh=fopen($file,'r');
        $list=array();
        while(!feof($fh))
        {
            $line = trim(fgets($fh));
            if(preg_match('/ \|\| /', $line)){
                $arr=preg_split('/ \|\| /',$line);
                $list[$arr[0]] = $arr[1];
            }
        }
        return $list;
    }
    
//finds a variable name in 'string' (enclosed in ##) and replaces it with var value
// var value comes from array, where the var name in string acts as a key
    function insertVarValues($string, $array){
        $output = '';
        $which = 2;
        $splices = preg_split('/##/',$string);
        foreach ($splices as $part){
            if ($which%2) {
                $output.=$array[$part];
            } else {
                $output.=$part;
            }
            $which++;
        }
        return $output;
    };
    
    function whereToGo($userID){
        $sub_folder = getcwd()."/subjects/".$userID;
        $need_to_have = getcwd()."/files_for_navigation.txt";
        #echo $need_to_have."<br>";
        #echo "subject folder: ".$sub_folder;
        $files = scandir($sub_folder, 0);
        if($files==FALSE){
            return FALSE;
        } 
        #echo "<br>";
        #print_r($files);
        #echo "<br>";
        $myfile = fopen($need_to_have, 'r') or die("Unable to open file!");
        while(!feof($myfile)) {
            $file1 = trim(fgets($myfile));
            if (array_search($file1, $files)){
                echo "<br>got file: ".$file1;
            } else {
                echo "<br>can't find: ".$file1;
                break;
            }
        }
        fclose($myfile);
        $newloc = str_replace("txt", "php", $file1);
        echo "<br>next location: ".$newloc;
        return $newloc;
    };
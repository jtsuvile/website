<?php
include_once('lib.php');
include_once('settings.php');
include('header.php');

if(array_key_exists('err',$_GET))
	$err=$_GET['err'];
    $userID=$_GET['userID'];

    $keys=array('cu_mother', 'cu_father','cu_born','cu_extended_stay','cu_how_long','cu_where','cu_return_age','cu_preference');

    if(isset($err))
    {
        $loc = $keys[$err];
        $msg=$pagetexts['bg_err'].' '.$pagetexts[$loc];
        $errormsg="<br><div class=\"error\">$msg</div><br><br>";
    }

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">

<html>
<head>
<title><?php echo $pagetexts['title']; ?></title>
<LINK href="css/main.css" rel="stylesheet" type="text/css">
<meta http-equiv="Content-type" content="text/html;charset=UTF-8">
</head>
<body onload="checkDisable();">

<div id="header">
<h1><?php echo $pagetexts['cu_title'];?></h1></div>
<div id="container">
<div style="padding-left:10px">
<style>
td{
    padding:10px;
    }
input{
    margin-right:3px;
    }
</style>
<br>
<br>
<?php if(isset($errormsg)) echo $errormsg; ?>
<form method="POST" action="add_cult_backg.php">
<input type="hidden" name="userID" value="<?php echo $userID; ?>" />
<table>
    <tr style="background:#ccc">
        <td style="width:200px"><?php echo $pagetexts['cu_mother'];?></td>
        <td>
<input type="radio" name="cu_mother" value="japanese" <?php if(isset($_SESSION['cu_mother'])&&$_SESSION['cu_mother']==="japanese"){?>checked="checked"<?php }?> > <?php echo $pagetexts['cu_jp'];?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="cu_mother" value="asian" <?php if(isset($_SESSION['cu_mother'])&&$_SESSION['cu_mother']==="asian"){?>checked="checked"<?php }?>><?php echo $pagetexts['cu_as'];?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="cu_mother" value="white" <?php if(isset($_SESSION['cu_mother'])&&$_SESSION['cu_mother']==="white"){?>checked="checked"<?php }?>><?php echo $pagetexts['cu_wh'];?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="cu_mother" value="black" <?php if(isset($_SESSION['cu_mother'])&&$_SESSION['cu_mother']==="black"){?>checked="checked"<?php }?>><?php echo $pagetexts['cu_bl'];?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="cu_mother" value="hispanic" <?php if(isset($_SESSION['cu_mother'])&&$_SESSION['cu_mother']==="hispanic"){?>checked="checked"<?php }?>><?php echo $pagetexts['cu_hisp'];?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="cu_mother" value="other" <?php if(isset($_SESSION['cu_mother'])&&$_SESSION['cu_mother']==="other"){?>checked="checked"<?php }?>><?php echo $pagetexts['cu_other'];?>&nbsp;&nbsp;&nbsp;&nbsp;
        </td>
    </tr>
        <tr style="background:#eee">
            <td style="width:200px"><?php echo $pagetexts['cu_father'];?></td>
            <td>
    <input type="radio" name="cu_father" value="japanese" <?php if(isset($_SESSION['cu_father'])&&$_SESSION['cu_father']==="japanese"){?>checked="checked"<?php }?> > <?php echo $pagetexts['cu_jp'];?>&nbsp;&nbsp;&nbsp;&nbsp;
    <input type="radio" name="cu_father" value="asian" <?php if(isset($_SESSION['cu_father'])&&$_SESSION['cu_father']==="asian"){?>checked="checked"<?php }?>><?php echo $pagetexts['cu_as'];?>&nbsp;&nbsp;&nbsp;&nbsp;
    <input type="radio" name="cu_father" value="white" <?php if(isset($_SESSION['cu_father'])&&$_SESSION['cu_father']==="white"){?>checked="checked"<?php }?>><?php echo $pagetexts['cu_wh'];?>&nbsp;&nbsp;&nbsp;&nbsp;
    <input type="radio" name="cu_father" value="black" <?php if(isset($_SESSION['cu_father'])&&$_SESSION['cu_father']==="black"){?>checked="checked"<?php }?>><?php echo $pagetexts['cu_bl'];?>&nbsp;&nbsp;&nbsp;&nbsp;
    <input type="radio" name="cu_father" value="hispanic" <?php if(isset($_SESSION['cu_father'])&&$_SESSION['cu_father']==="hispanic"){?>checked="checked"<?php }?>><?php echo $pagetexts['cu_hisp'];?>&nbsp;&nbsp;&nbsp;&nbsp;
    <input type="radio" name="cu_father" value="other" <?php if(isset($_SESSION['cu_father'])&&$_SESSION['cu_father']==="other"){?>checked="checked"<?php }?>><?php echo $pagetexts['cu_other'];?>&nbsp;&nbsp;&nbsp;&nbsp;
            </td>
        </tr>
            <tr style="background:#ccc">
                <td style="width:200px"><?php echo $pagetexts['cu_born'];?></td>
                <td>
        <select name="cu_born">
            <option value=""><?php echo $pagetexts['select']?></option>
<option value="AF"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="AF") {?> SELECTED <?php } ?>>アフガニスタン・イスラム共和国</option>　
<option value="AL"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="AL") {?> SELECTED <?php } ?>>アルバニア共和国</option>
<option value="DZ"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="DZ") {?> SELECTED <?php } ?>>アルジェリア民主人民共和国</option>　
<option value="AD"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="AD") {?> SELECTED <?php } ?>>アンドラ公国</option>　
<option value="AO"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="AO") {?> SELECTED <?php } ?>>アンゴラ共和国</option>　
<option value="AG"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="AG") {?> SELECTED <?php } ?>>アンティグア・バーブーダ</option>　
<option value="AR"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="AR") {?> SELECTED <?php } ?>>アルゼンチン共和国</option>
<option value="AM"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="AM") {?> SELECTED <?php } ?>>アルメニア共和国</option>　
<option value="AU"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="AU") {?> SELECTED <?php } ?>>オーストラリアおよびその海外領土・自治領</option>
<option value="AT"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="AT") {?> SELECTED <?php } ?>>オーストリア共和国</option>
<option value="AZ"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="AZ") {?> SELECTED <?php } ?>>アゼルバイジャン共和国</option>
<option value="BS"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="BS") {?> SELECTED <?php } ?>>バハマ</option>
<option value="BH"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="BH") {?> SELECTED <?php } ?>>バーレーン王国 </option>
<option value="BD"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="BD") {?> SELECTED <?php } ?>>バングラデシュ人民共和国</option>
<option value="BB"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="BB") {?> SELECTED <?php } ?>>バルバドス</option>
<option value="BY"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="BY") {?> SELECTED <?php } ?>>ベラルーシ共和国</option>
<option value="BE"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="BE") {?> SELECTED <?php } ?>>ベルギー王国</option>
<option value="BZ"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="BZ") {?> SELECTED <?php } ?>>ベリーズ</option>
<option value="BJ"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="BJ") {?> SELECTED <?php } ?>>ベナン共和国</option>
<option value="BT"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="BT") {?> SELECTED <?php } ?>>ブータン王国</option>
<option value="BO"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="BO") {?> SELECTED <?php } ?>>ボリビア多民族国</option>
<option value="BA"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="BA") {?> SELECTED <?php } ?>>ボスニア・ヘルツェゴビナ</option>
<option value="BW"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="BW") {?> SELECTED <?php } ?>>ボツワナ共和国</option>
<option value="BR"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="BR") {?> SELECTED <?php } ?>>ブラジル連邦共和国</option>
<option value="BN"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="BN") {?> SELECTED <?php } ?>>ブルネイ・ダルサラーム国</option>
<option value="BG"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="BG") {?> SELECTED <?php } ?>>ブルガリア共和国 </option>
<option value="BF"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="BF") {?> SELECTED <?php } ?>>ブルキナファソ</option>
<option value="BI"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="BI") {?> SELECTED <?php } ?>>ブルンジ共和国</option>
<option value="KH"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="KH") {?> SELECTED <?php } ?>>カンボジア王国</option>
<option value="CM"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="CM") {?> SELECTED <?php } ?>>カメルーン共和国 </option>
<option value="CA"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="CA") {?> SELECTED <?php } ?>>カナダ</option>
<option value="CV"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="CV") {?> SELECTED <?php } ?>>カーボベルデ共和国</option>
<option value="CF"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="CF") {?> SELECTED <?php } ?>>中央アフリカ共和国</option>
<option value="TD"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="TD") {?> SELECTED <?php } ?>>チャド共和国</option>
<option value="CL"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="CL") {?> SELECTED <?php } ?>>チリ共和国およびその海外領土・自治領</option>
<option value="CN"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="CN") {?> SELECTED <?php } ?>>中華人民共和国</option>
<option value="CO"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="CO") {?> SELECTED <?php } ?>>コロンビア共和国</option>
<option value="KM"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="KM") {?> SELECTED <?php } ?>>コモロ連合</option>
<option value="CG"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="CG") {?> SELECTED <?php } ?>>コンゴ共和国</option>
<option value="CD"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="CD") {?> SELECTED <?php } ?>>コンゴ民主共和国</option>
<option value="CR"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="CR") {?> SELECTED <?php } ?>>コスタリカ共和国</option>
<option value="CI"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="CI") {?> SELECTED <?php } ?>>コートジボワール共和国</option>
<option value="HR"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="HR") {?> SELECTED <?php } ?>>クロアチア共和国</option>
<option value="CU"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="CU") {?> SELECTED <?php } ?>>キューバ共和国</option>
<option value="CY"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="CY") {?> SELECTED <?php } ?>>キプロス共和国</option>
<option value="CZ"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="CZ") {?> SELECTED <?php } ?>>チェコ共和国</option>
<option value="DK"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="DK") {?> SELECTED <?php } ?>>デンマーク王国およびその海外領土・自治領</option>
<option value="DJ"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="DJ") {?> SELECTED <?php } ?>>ジブチ共和国</option>
<option value="DM"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="DM") {?> SELECTED <?php } ?>>ドミニカ</option>
<option value="DO"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="DO") {?> SELECTED <?php } ?>>ドミニカ共和国</option>
<option value="EC"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="EC") {?> SELECTED <?php } ?>>エクアドル共和国</option>
<option value="EG"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="EG") {?> SELECTED <?php } ?>>エジプト・アラブ共和国 </option>
<option value="SV"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="SV") {?> SELECTED <?php } ?>>エルサルバドル共和国</option>
<option value="GQ"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="GQ") {?> SELECTED <?php } ?>>赤道ギニア共和国</option>
<option value="ER"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="ER") {?> SELECTED <?php } ?>>エリトリア</option>
<option value="EE"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="EE") {?> SELECTED <?php } ?>>エストニア共和国</option>
<option value="ET"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="ET") {?> SELECTED <?php } ?>>エチオピア連邦民主共和国</option>
<option value="FJ"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="FJ") {?> SELECTED <?php } ?>>フィジー共和国</option>
<option value="FI"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="FI") {?> SELECTED <?php } ?>>フィンランド共和国およびその海外領土・自治領</option>
<option value="FR"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="FR") {?> SELECTED <?php } ?>>フランス共和国およびその海外領土・自治領</option>
<option value="GA"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="GA") {?> SELECTED <?php } ?>>ガボン共和国</option>
<option value="GM"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="GM") {?> SELECTED <?php } ?>>ガンビア・イスラム共和国</option>
<option value="GE"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="GE") {?> SELECTED <?php } ?>>ジョ​​ージア</option>
<option value="DE"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="DE") {?> SELECTED <?php } ?>>ドイツ連邦共和国 </option>
<option value="GH"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="GH") {?> SELECTED <?php } ?>>ガーナ共和国</option>
<option value="GR"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="GR") {?> SELECTED <?php } ?>>ギリシャ共和国</option>
<option value="GD"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="GD") {?> SELECTED <?php } ?>>グレナダ</option>
<option value="GT"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="GT") {?> SELECTED <?php } ?>>グアテマラ共和国</option>
<option value="GN"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="GN") {?> SELECTED <?php } ?>>ギニア共和国</option>
<option value="GW"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="GW") {?> SELECTED <?php } ?>>ギニアビサウ共和国</option>
<option value="GY"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="GY") {?> SELECTED <?php } ?>>ガイアナ共和国</option>
<option value="HT"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="HT") {?> SELECTED <?php } ?>>ハイチ共和国</option>
<option value="VA"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="VA") {?> SELECTED <?php } ?>>バチカン市国</option>
<option value="HN"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="HN") {?> SELECTED <?php } ?>>ホンジュラス共和国</option>
<option value="HU"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="HU") {?> SELECTED <?php } ?>>ハンガリー</option>
<option value="IS"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="IS") {?> SELECTED <?php } ?>>アイスランド共和国</option>
<option value="IN"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="IN") {?> SELECTED <?php } ?>>インド</option>
<option value="ID"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="ID") {?> SELECTED <?php } ?>>インドネシア共和国</option>
<option value="IR"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="IR") {?> SELECTED <?php } ?>>イラン・イスラム共和国</option>
<option value="IQ"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="IQ") {?> SELECTED <?php } ?>>イラク共和国</option>
<option value="IE"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="IE") {?> SELECTED <?php } ?>>アイルランド</option>
<option value="IL"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="IL") {?> SELECTED <?php } ?>>イスラエル</option>
<option value="IT"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="IT") {?> SELECTED <?php } ?>>イタリア共和国</option>
<option value="JM"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="JM") {?> SELECTED <?php } ?>>ジャマイカ</option>
<option value="JP"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="JP") {?> SELECTED <?php } ?>>日本</option>
<option value="JO"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="JO") {?> SELECTED <?php } ?>>ヨルダン・ハシェミット王国</option>
<option value="KZ"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="KZ") {?> SELECTED <?php } ?>>カザフスタン共和国</option>
<option value="KE"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="KE") {?> SELECTED <?php } ?>>ケニア共和国</option>
<option value="KI"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="KI") {?> SELECTED <?php } ?>>キリバス共和国</option>
<option value="KP"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="KP") {?> SELECTED <?php } ?>>朝鮮民主主義人民共和国(北朝鮮）</option>
<option value="KR"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="KR") {?> SELECTED <?php } ?>>大韓民国</option>
<option value="KW"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="KW") {?> SELECTED <?php } ?>>クウェート</option>
<option value="KG"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="KG") {?> SELECTED <?php } ?>>キルギス共和国</option>
<option value="LA"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="LA") {?> SELECTED <?php } ?>>ラオス人民民主共和国</option>
<option value="LV"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="LV") {?> SELECTED <?php } ?>>ラトビア共和国</option>
<option value="LB"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="LB") {?> SELECTED <?php } ?>>レバノン共和国</option>
<option value="LS"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="LS") {?> SELECTED <?php } ?>>レソト王国</option>
<option value="LR"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="LR") {?> SELECTED <?php } ?>>リベリア共和国</option>
<option value="LY"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="LY") {?> SELECTED <?php } ?>>リビア</option>
<option value="LI"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="LI") {?> SELECTED <?php } ?>>リヒテンシュタイン公国</option>
<option value="LT"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="LT") {?> SELECTED <?php } ?>>リトアニア共和国</option>
<option value="LU"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="LU") {?> SELECTED <?php } ?>>ルクセンブルク大公国</option>
<option value="MK"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="MK") {?> SELECTED <?php } ?>>マケドニア社会主義共和国</option>
<option value="MG"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="MG") {?> SELECTED <?php } ?>>マダガスカル共和国 </option>
<option value="MW"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="MW") {?> SELECTED <?php } ?>>マラウイ共和国</option>
<option value="MY"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="MY") {?> SELECTED <?php } ?>>マレーシア</option>
<option value="MV"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="MV") {?> SELECTED <?php } ?>>モルディブ共和国</option>
<option value="ML"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="ML") {?> SELECTED <?php } ?>>マリ共和国</option>
<option value="MT"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="MT") {?> SELECTED <?php } ?>>マルタ共和国</option>
<option value="MH"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="MH") {?> SELECTED <?php } ?>>マーシャル諸島共和国</option>
<option value="MR"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="MR") {?> SELECTED <?php } ?>>モーリタニア・イスラム共和国</option>
<option value="MU"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="MU") {?> SELECTED <?php } ?>>モーリシャス共和国</option>
<option value="MX"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="MX") {?> SELECTED <?php } ?>>メキシコ合衆国</option>
<option value="FM"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="FM") {?> SELECTED <?php } ?>>ミクロネシア連邦</option>
<option value="MD"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="MD") {?> SELECTED <?php } ?>>モルドバ共和国</option>
<option value="MC"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="MC") {?> SELECTED <?php } ?>>モナコ公国</option>
<option value="MN"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="MN") {?> SELECTED <?php } ?>>モンゴル</option>
<option value="ME"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="ME") {?> SELECTED <?php } ?>>モンテネグロ</option>
<option value="MA"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="MA") {?> SELECTED <?php } ?>>モロッコ王国</option>
<option value="MZ"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="MZ") {?> SELECTED <?php } ?>>モザンビーク共和国</option>
<option value="MM"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="MM") {?> SELECTED <?php } ?>>ミャンマー連邦共和国</option>
<option value="NA"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="NA") {?> SELECTED <?php } ?>>ナミビア共和国</option>
<option value="NR"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="NR") {?> SELECTED <?php } ?>>ナウル共和国</option>
<option value="NP"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="NP") {?> SELECTED <?php } ?>>ネパール連邦民主共和国</option>
<option value="NL"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="NL") {?> SELECTED <?php } ?>>オランダ王国 およびその海外領土・自治領</option>
<option value="NZ"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="NZ") {?> SELECTED <?php } ?>>ニュージーランド</option>
<option value="NI"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="NI") {?> SELECTED <?php } ?>>ニカラグア共和国</option>
<option value="NE"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="NE") {?> SELECTED <?php } ?>>ニジェール共和国</option>
<option value="NG"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="NG") {?> SELECTED <?php } ?>>ナイジェリア連邦共和国</option>
<option value="NU"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="NU") {?> SELECTED <?php } ?>>ニウエ</option>
<option value="NO"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="NO") {?> SELECTED <?php } ?>>ノルウェー王国およびその海外領土・自治領</option>
<option value="OM"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="OM") {?> SELECTED <?php } ?>>オマーン</option>
<option value="PK"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="PK") {?> SELECTED <?php } ?>>パキスタン・イスラム共和国</option>
<option value="PW"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="PW") {?> SELECTED <?php } ?>>パラオ共和国</option>
<option value="PS"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="PS") {?> SELECTED <?php } ?>>パレスチナ自治区</option>
<option value="PA"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="PA") {?> SELECTED <?php } ?>>パナマ共和国</option>
<option value="PG"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="PG") {?> SELECTED <?php } ?>>パプアニューギニア独立国</option>
<option value="PY"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="PY") {?> SELECTED <?php } ?>>パラグアイ共和国</option>
<option value="PE"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="PE") {?> SELECTED <?php } ?>>ペルー共和国</option>
<option value="PH"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="PH") {?> SELECTED <?php } ?>>フィリピン共和国</option>
<option value="PL"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="PL") {?> SELECTED <?php } ?>>ポーランド共和国</option>
<option value="PT"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="PT") {?> SELECTED <?php } ?>>ポル​​トガル共和国</option>
<option value="QA"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="QA") {?> SELECTED <?php } ?>>カタール</option>
<option value="RO"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="RO") {?> SELECTED <?php } ?>>ルーマニア</option>
<option value="RU"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="RU") {?> SELECTED <?php } ?>>ロシア連邦</option>
<option value="RW"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="RW") {?> SELECTED <?php } ?>>ルワンダ共和国</option>
<option value="KN"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="KN") {?> SELECTED <?php } ?>>セントクリストファー・ネイビス連邦</option>
<option value="LC"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="LC") {?> SELECTED <?php } ?>>セントルシア</option>
<option value="VC"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="VC") {?> SELECTED <?php } ?>>セントビンセント・グレナディーン諸島</option>
<option value="WS"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="WS") {?> SELECTED <?php } ?>>サモア独立国</option>
<option value="SM"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="SM") {?> SELECTED <?php } ?>>サンマリノ共和国</option>
<option value="SA"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="SA") {?> SELECTED <?php } ?>>サウジアラビア王国</option>
<option value="SN"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="SN") {?> SELECTED <?php } ?>>セネガル共和国</option>
<option value="RS"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="RS") {?> SELECTED <?php } ?>>セルビア共和国</option>
<option value="SC"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="SC") {?> SELECTED <?php } ?>>セ－シェル共和国</option>
<option value="SL"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="SL") {?> SELECTED <?php } ?>>シエラレオネ共和国</option>
<option value="SG"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="SG") {?> SELECTED <?php } ?>>シンガポール</option>
<option value="SK"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="SK") {?> SELECTED <?php } ?>>スロバキア共和国</option>
<option value="SI"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="SI") {?> SELECTED <?php } ?>>スロベニア共和国</option>
<option value="SB"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="SB") {?> SELECTED <?php } ?>>ソロモン諸島</option>
<option value="SO"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="SO") {?> SELECTED <?php } ?>>ソマリア連邦共和国</option>
<option value="ZA"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="ZA") {?> SELECTED <?php } ?>>南アフリカ共和国</option>
<option value="SS"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="SS") {?> SELECTED <?php } ?>>南スーダン共和国</option>
<option value="ES"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="ES") {?> SELECTED <?php } ?>>スペイン</option>
<option value="LK"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="LK") {?> SELECTED <?php } ?>>スリランカ民主社会主義共和国</option>
<option value="SR"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="SR") {?> SELECTED <?php } ?>>スリナム共和国</option>
<option value="SJ"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="SJ") {?> SELECTED <?php } ?>>スバールバル諸島とヤンマイエン</オプション></option>
<option value="SZ"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="SZ") {?> SELECTED <?php } ?>>スワジランド王国</option>
<option value="SE"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="SE") {?> SELECTED <?php } ?>>スウェーデン王国</option>
<option value="CH"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="CH") {?> SELECTED <?php } ?>>スイス連邦</option>
<option value="SY"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="SY") {?> SELECTED <?php } ?>>シリア・アラブ共和国</option>
<option value="TW"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="TW") {?> SELECTED <?php } ?>>台湾</option>
<option value="TJ"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="TJ") {?> SELECTED <?php } ?>>タジキスタン共和国</option>
<option value="TZ"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="TZ") {?> SELECTED <?php } ?>>タンザニア連合共和国</option>
<option value="TH"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="TH") {?> SELECTED <?php } ?>>タイ王国</option>
<option value="TL"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="TL") {?> SELECTED <?php } ?>>東ティモール民主共和国</option>
<option value="TG"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="TG") {?> SELECTED <?php } ?>>トーゴ共和国</option>
<option value="TO"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="TO") {?> SELECTED <?php } ?>>トンガ王国 </option>
<option value="TT"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="TT") {?> SELECTED <?php } ?>>トリニダード・トバゴ共和国</option>
<option value="TN"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="TN") {?> SELECTED <?php } ?>>チュニジア共和国</option>
<option value="TR"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="TR") {?> SELECTED <?php } ?>>トルコ共和国</option>
<option value="TM"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="TM") {?> SELECTED <?php } ?>>トルクメニスタン</option>
<option value="TV"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="TV") {?> SELECTED <?php } ?>>ツバル</option>
<option value="UG"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="UG") {?> SELECTED <?php } ?>>ウガンダ共和国</option>
<option value="UA"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="UA") {?> SELECTED <?php } ?>>ウクライナ</option>
<option value="AE"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="AE") {?> SELECTED <?php } ?>>アラブ首長国連邦</option>
<option value="GB"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="GB") {?> SELECTED <?php } ?>>イギリス（グレートブリテン及び北アイルランド連合王国）およびその海外領土</option>
<option value="US"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="US") {?> SELECTED <?php } ?>>アメリカ合衆国およびその国外諸島・自治領</option>
<option value="UY"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="UY") {?> SELECTED <?php } ?>>ウルグアイ東方共和国</option>
<option value="UZ"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="UZ") {?> SELECTED <?php } ?>>ウズベキスタン共和国</option>
<option value="VU"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="VU") {?> SELECTED <?php } ?>>バヌアツ共和国</option>
<option value="VE"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="VE") {?> SELECTED <?php } ?>>ベネズエラ・ボリバル共和国</option>
<option value="VN"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="VN") {?> SELECTED <?php } ?>>ベトナム社会主義共和国</option>
<option value="YE"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="YE") {?> SELECTED <?php } ?>>イエメン共和国 </option>
<option value="ZM"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="ZM") {?> SELECTED <?php } ?>>ザンビア共和国</option>
<option value="ZW"<?php if(isset($_SESSION['cu_born'])&&$_SESSION['cu_born']=="ZW") {?> SELECTED <?php } ?>>ジンバブエ共和国</option>
        </select>
                </td>
            </tr>
        
    <tr style="background:#eee">
        <td style="width:200px"><?php echo $pagetexts['cu_extended_stay'];?></td>
        <td>
<input type="radio" name="cu_extended_stay" value="0" id="cntrl" onclick="checkDisable();" <?php if(isset($_SESSION['cu_extended_stay'])&&$_SESSION['cu_extended_stay']==="0"){?>checked="checked"<?php }?> > <?php echo $pagetexts['rp_n'];?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="cu_extended_stay" value="1" onclick="checkDisable();" <?php if(isset($_SESSION['cu_extended_stay'])&&$_SESSION['cu_extended_stay']==="1"){?>checked="checked"<?php }?>><?php echo $pagetexts['rp_y'];?>&nbsp;&nbsp;&nbsp;&nbsp; 

        </td>
    </tr> 
    <tr style="background:#ccc" >
        <td colspan="2"> <?php echo $pagetexts['cu_these_too'];?></td>
    </tr>
    <tr style="background:#eee;">
        <td style="width:200px"><?php echo $pagetexts['cu_how_long'];?></td>
        <td>
            <select disabled name="cu_how_long" id="conditi">
            <option value=""><?php echo $pagetexts['select']?></option>
            <?php
                for($i=1;$i<100;$i++){
                    $str="";
                    if(isset($_SESSION['cu_how_long'])&&$i==$_SESSION['cu_how_long']) $str=" SELECTED ";
                    if($i==0 && !isset($_SESSION['cu_how_long'])) $str=" SELECTED ";
                    echo "<option value=\"$i\"  $str>$i</option>";  
                }
            ?>
            </select> 
            <?php echo $pagetexts['rp_years'];?>
        </td>
    </tr>

    <tr style="background:#ccc">
        <td style="width:200px"><?php echo $pagetexts['cu_where'];?></td>
        <td>
<select name="cu_where" id="conditi2">
    <option value=""><?php echo $pagetexts['select']?></option>
<option value="AF"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="AF") {?> SELECTED <?php } ?>>アフガニスタン・イスラム共和国</option>　
<option value="AL"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="AL") {?> SELECTED <?php } ?>>アルバニア共和国</option>
<option value="DZ"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="DZ") {?> SELECTED <?php } ?>>アルジェリア民主人民共和国</option>　
<option value="AD"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="AD") {?> SELECTED <?php } ?>>アンドラ公国</option>　
<option value="AO"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="AO") {?> SELECTED <?php } ?>>アンゴラ共和国</option>　
<option value="AG"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="AG") {?> SELECTED <?php } ?>>アンティグア・バーブーダ</option>　
<option value="AR"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="AR") {?> SELECTED <?php } ?>>アルゼンチン共和国</option>
<option value="AM"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="AM") {?> SELECTED <?php } ?>>アルメニア共和国</option>　
<option value="AU"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="AU") {?> SELECTED <?php } ?>>オーストラリアおよびその海外領土・自治領</option>
<option value="AT"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="AT") {?> SELECTED <?php } ?>>オーストリア共和国</option>
<option value="AZ"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="AZ") {?> SELECTED <?php } ?>>アゼルバイジャン共和国</option>
<option value="BS"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="BS") {?> SELECTED <?php } ?>>バハマ</option>
<option value="BH"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="BH") {?> SELECTED <?php } ?>>バーレーン王国 </option>
<option value="BD"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="BD") {?> SELECTED <?php } ?>>バングラデシュ人民共和国</option>
<option value="BB"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="BB") {?> SELECTED <?php } ?>>バルバドス</option>
<option value="BY"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="BY") {?> SELECTED <?php } ?>>ベラルーシ共和国</option>
<option value="BE"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="BE") {?> SELECTED <?php } ?>>ベルギー王国</option>
<option value="BZ"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="BZ") {?> SELECTED <?php } ?>>ベリーズ</option>
<option value="BJ"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="BJ") {?> SELECTED <?php } ?>>ベナン共和国</option>
<option value="BT"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="BT") {?> SELECTED <?php } ?>>ブータン王国</option>
<option value="BO"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="BO") {?> SELECTED <?php } ?>>ボリビア多民族国</option>
<option value="BA"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="BA") {?> SELECTED <?php } ?>>ボスニア・ヘルツェゴビナ</option>
<option value="BW"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="BW") {?> SELECTED <?php } ?>>ボツワナ共和国</option>
<option value="BR"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="BR") {?> SELECTED <?php } ?>>ブラジル連邦共和国</option>
<option value="BN"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="BN") {?> SELECTED <?php } ?>>ブルネイ・ダルサラーム国</option>
<option value="BG"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="BG") {?> SELECTED <?php } ?>>ブルガリア共和国 </option>
<option value="BF"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="BF") {?> SELECTED <?php } ?>>ブルキナファソ</option>
<option value="BI"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="BI") {?> SELECTED <?php } ?>>ブルンジ共和国</option>
<option value="KH"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="KH") {?> SELECTED <?php } ?>>カンボジア王国</option>
<option value="CM"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="CM") {?> SELECTED <?php } ?>>カメルーン共和国 </option>
<option value="CA"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="CA") {?> SELECTED <?php } ?>>カナダ</option>
<option value="CV"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="CV") {?> SELECTED <?php } ?>>カーボベルデ共和国</option>
<option value="CF"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="CF") {?> SELECTED <?php } ?>>中央アフリカ共和国</option>
<option value="TD"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="TD") {?> SELECTED <?php } ?>>チャド共和国</option>
<option value="CL"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="CL") {?> SELECTED <?php } ?>>チリ共和国およびその海外領土・自治領</option>
<option value="CN"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="CN") {?> SELECTED <?php } ?>>中華人民共和国</option>
<option value="CO"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="CO") {?> SELECTED <?php } ?>>コロンビア共和国</option>
<option value="KM"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="KM") {?> SELECTED <?php } ?>>コモロ連合</option>
<option value="CG"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="CG") {?> SELECTED <?php } ?>>コンゴ共和国</option>
<option value="CD"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="CD") {?> SELECTED <?php } ?>>コンゴ民主共和国</option>
<option value="CR"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="CR") {?> SELECTED <?php } ?>>コスタリカ共和国</option>
<option value="CI"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="CI") {?> SELECTED <?php } ?>>コートジボワール共和国</option>
<option value="HR"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="HR") {?> SELECTED <?php } ?>>クロアチア共和国</option>
<option value="CU"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="CU") {?> SELECTED <?php } ?>>キューバ共和国</option>
<option value="CY"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="CY") {?> SELECTED <?php } ?>>キプロス共和国</option>
<option value="CZ"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="CZ") {?> SELECTED <?php } ?>>チェコ共和国</option>
<option value="DK"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="DK") {?> SELECTED <?php } ?>>デンマーク王国およびその海外領土・自治領</option>
<option value="DJ"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="DJ") {?> SELECTED <?php } ?>>ジブチ共和国</option>
<option value="DM"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="DM") {?> SELECTED <?php } ?>>ドミニカ</option>
<option value="DO"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="DO") {?> SELECTED <?php } ?>>ドミニカ共和国</option>
<option value="EC"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="EC") {?> SELECTED <?php } ?>>エクアドル共和国</option>
<option value="EG"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="EG") {?> SELECTED <?php } ?>>エジプト・アラブ共和国 </option>
<option value="SV"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="SV") {?> SELECTED <?php } ?>>エルサルバドル共和国</option>
<option value="GQ"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="GQ") {?> SELECTED <?php } ?>>赤道ギニア共和国</option>
<option value="ER"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="ER") {?> SELECTED <?php } ?>>エリトリア</option>
<option value="EE"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="EE") {?> SELECTED <?php } ?>>エストニア共和国</option>
<option value="ET"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="ET") {?> SELECTED <?php } ?>>エチオピア連邦民主共和国</option>
<option value="FJ"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="FJ") {?> SELECTED <?php } ?>>フィジー共和国</option>
<option value="FI"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="FI") {?> SELECTED <?php } ?>>フィンランド共和国およびその海外領土・自治領</option>
<option value="FR"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="FR") {?> SELECTED <?php } ?>>フランス共和国およびその海外領土・自治領</option>
<option value="GA"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="GA") {?> SELECTED <?php } ?>>ガボン共和国</option>
<option value="GM"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="GM") {?> SELECTED <?php } ?>>ガンビア・イスラム共和国</option>
<option value="GE"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="GE") {?> SELECTED <?php } ?>>ジョ​​ージア</option>
<option value="DE"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="DE") {?> SELECTED <?php } ?>>ドイツ連邦共和国 </option>
<option value="GH"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="GH") {?> SELECTED <?php } ?>>ガーナ共和国</option>
<option value="GR"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="GR") {?> SELECTED <?php } ?>>ギリシャ共和国</option>
<option value="GD"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="GD") {?> SELECTED <?php } ?>>グレナダ</option>
<option value="GT"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="GT") {?> SELECTED <?php } ?>>グアテマラ共和国</option>
<option value="GN"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="GN") {?> SELECTED <?php } ?>>ギニア共和国</option>
<option value="GW"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="GW") {?> SELECTED <?php } ?>>ギニアビサウ共和国</option>
<option value="GY"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="GY") {?> SELECTED <?php } ?>>ガイアナ共和国</option>
<option value="HT"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="HT") {?> SELECTED <?php } ?>>ハイチ共和国</option>
<option value="VA"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="VA") {?> SELECTED <?php } ?>>バチカン市国</option>
<option value="HN"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="HN") {?> SELECTED <?php } ?>>ホンジュラス共和国</option>
<option value="HU"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="HU") {?> SELECTED <?php } ?>>ハンガリー</option>
<option value="IS"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="IS") {?> SELECTED <?php } ?>>アイスランド共和国</option>
<option value="IN"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="IN") {?> SELECTED <?php } ?>>インド</option>
<option value="ID"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="ID") {?> SELECTED <?php } ?>>インドネシア共和国</option>
<option value="IR"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="IR") {?> SELECTED <?php } ?>>イラン・イスラム共和国</option>
<option value="IQ"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="IQ") {?> SELECTED <?php } ?>>イラク共和国</option>
<option value="IE"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="IE") {?> SELECTED <?php } ?>>アイルランド</option>
<option value="IL"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="IL") {?> SELECTED <?php } ?>>イスラエル</option>
<option value="IT"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="IT") {?> SELECTED <?php } ?>>イタリア共和国</option>
<option value="JM"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="JM") {?> SELECTED <?php } ?>>ジャマイカ</option>
<option value="JP"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="JP") {?> SELECTED <?php } ?>>日本</option>
<option value="JO"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="JO") {?> SELECTED <?php } ?>>ヨルダン・ハシェミット王国</option>
<option value="KZ"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="KZ") {?> SELECTED <?php } ?>>カザフスタン共和国</option>
<option value="KE"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="KE") {?> SELECTED <?php } ?>>ケニア共和国</option>
<option value="KI"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="KI") {?> SELECTED <?php } ?>>キリバス共和国</option>
<option value="KP"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="KP") {?> SELECTED <?php } ?>>朝鮮民主主義人民共和国(北朝鮮）</option>
<option value="KR"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="KR") {?> SELECTED <?php } ?>>大韓民国</option>
<option value="KW"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="KW") {?> SELECTED <?php } ?>>クウェート</option>
<option value="KG"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="KG") {?> SELECTED <?php } ?>>キルギス共和国</option>
<option value="LA"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="LA") {?> SELECTED <?php } ?>>ラオス人民民主共和国</option>
<option value="LV"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="LV") {?> SELECTED <?php } ?>>ラトビア共和国</option>
<option value="LB"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="LB") {?> SELECTED <?php } ?>>レバノン共和国</option>
<option value="LS"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="LS") {?> SELECTED <?php } ?>>レソト王国</option>
<option value="LR"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="LR") {?> SELECTED <?php } ?>>リベリア共和国</option>
<option value="LY"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="LY") {?> SELECTED <?php } ?>>リビア</option>
<option value="LI"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="LI") {?> SELECTED <?php } ?>>リヒテンシュタイン公国</option>
<option value="LT"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="LT") {?> SELECTED <?php } ?>>リトアニア共和国</option>
<option value="LU"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="LU") {?> SELECTED <?php } ?>>ルクセンブルク大公国</option>
<option value="MK"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="MK") {?> SELECTED <?php } ?>>マケドニア社会主義共和国</option>
<option value="MG"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="MG") {?> SELECTED <?php } ?>>マダガスカル共和国 </option>
<option value="MW"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="MW") {?> SELECTED <?php } ?>>マラウイ共和国</option>
<option value="MY"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="MY") {?> SELECTED <?php } ?>>マレーシア</option>
<option value="MV"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="MV") {?> SELECTED <?php } ?>>モルディブ共和国</option>
<option value="ML"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="ML") {?> SELECTED <?php } ?>>マリ共和国</option>
<option value="MT"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="MT") {?> SELECTED <?php } ?>>マルタ共和国</option>
<option value="MH"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="MH") {?> SELECTED <?php } ?>>マーシャル諸島共和国</option>
<option value="MR"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="MR") {?> SELECTED <?php } ?>>モーリタニア・イスラム共和国</option>
<option value="MU"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="MU") {?> SELECTED <?php } ?>>モーリシャス共和国</option>
<option value="MX"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="MX") {?> SELECTED <?php } ?>>メキシコ合衆国</option>
<option value="FM"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="FM") {?> SELECTED <?php } ?>>ミクロネシア連邦</option>
<option value="MD"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="MD") {?> SELECTED <?php } ?>>モルドバ共和国</option>
<option value="MC"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="MC") {?> SELECTED <?php } ?>>モナコ公国</option>
<option value="MN"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="MN") {?> SELECTED <?php } ?>>モンゴル</option>
<option value="ME"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="ME") {?> SELECTED <?php } ?>>モンテネグロ</option>
<option value="MA"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="MA") {?> SELECTED <?php } ?>>モロッコ王国</option>
<option value="MZ"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="MZ") {?> SELECTED <?php } ?>>モザンビーク共和国</option>
<option value="MM"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="MM") {?> SELECTED <?php } ?>>ミャンマー連邦共和国</option>
<option value="NA"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="NA") {?> SELECTED <?php } ?>>ナミビア共和国</option>
<option value="NR"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="NR") {?> SELECTED <?php } ?>>ナウル共和国</option>
<option value="NP"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="NP") {?> SELECTED <?php } ?>>ネパール連邦民主共和国</option>
<option value="NL"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="NL") {?> SELECTED <?php } ?>>オランダ王国 およびその海外領土・自治領</option>
<option value="NZ"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="NZ") {?> SELECTED <?php } ?>>ニュージーランド</option>
<option value="NI"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="NI") {?> SELECTED <?php } ?>>ニカラグア共和国</option>
<option value="NE"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="NE") {?> SELECTED <?php } ?>>ニジェール共和国</option>
<option value="NG"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="NG") {?> SELECTED <?php } ?>>ナイジェリア連邦共和国</option>
<option value="NU"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="NU") {?> SELECTED <?php } ?>>ニウエ</option>
<option value="NO"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="NO") {?> SELECTED <?php } ?>>ノルウェー王国およびその海外領土・自治領</option>
<option value="OM"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="OM") {?> SELECTED <?php } ?>>オマーン</option>
<option value="PK"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="PK") {?> SELECTED <?php } ?>>パキスタン・イスラム共和国</option>
<option value="PW"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="PW") {?> SELECTED <?php } ?>>パラオ共和国</option>
<option value="PS"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="PS") {?> SELECTED <?php } ?>>パレスチナ自治区</option>
<option value="PA"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="PA") {?> SELECTED <?php } ?>>パナマ共和国</option>
<option value="PG"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="PG") {?> SELECTED <?php } ?>>パプアニューギニア独立国</option>
<option value="PY"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="PY") {?> SELECTED <?php } ?>>パラグアイ共和国</option>
<option value="PE"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="PE") {?> SELECTED <?php } ?>>ペルー共和国</option>
<option value="PH"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="PH") {?> SELECTED <?php } ?>>フィリピン共和国</option>
<option value="PL"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="PL") {?> SELECTED <?php } ?>>ポーランド共和国</option>
<option value="PT"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="PT") {?> SELECTED <?php } ?>>ポル​​トガル共和国</option>
<option value="QA"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="QA") {?> SELECTED <?php } ?>>カタール</option>
<option value="RO"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="RO") {?> SELECTED <?php } ?>>ルーマニア</option>
<option value="RU"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="RU") {?> SELECTED <?php } ?>>ロシア連邦</option>
<option value="RW"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="RW") {?> SELECTED <?php } ?>>ルワンダ共和国</option>
<option value="KN"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="KN") {?> SELECTED <?php } ?>>セントクリストファー・ネイビス連邦</option>
<option value="LC"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="LC") {?> SELECTED <?php } ?>>セントルシア</option>
<option value="VC"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="VC") {?> SELECTED <?php } ?>>セントビンセント・グレナディーン諸島</option>
<option value="WS"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="WS") {?> SELECTED <?php } ?>>サモア独立国</option>
<option value="SM"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="SM") {?> SELECTED <?php } ?>>サンマリノ共和国</option>
<option value="SA"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="SA") {?> SELECTED <?php } ?>>サウジアラビア王国</option>
<option value="SN"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="SN") {?> SELECTED <?php } ?>>セネガル共和国</option>
<option value="RS"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="RS") {?> SELECTED <?php } ?>>セルビア共和国</option>
<option value="SC"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="SC") {?> SELECTED <?php } ?>>セ－シェル共和国</option>
<option value="SL"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="SL") {?> SELECTED <?php } ?>>シエラレオネ共和国</option>
<option value="SG"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="SG") {?> SELECTED <?php } ?>>シンガポール</option>
<option value="SK"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="SK") {?> SELECTED <?php } ?>>スロバキア共和国</option>
<option value="SI"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="SI") {?> SELECTED <?php } ?>>スロベニア共和国</option>
<option value="SB"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="SB") {?> SELECTED <?php } ?>>ソロモン諸島</option>
<option value="SO"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="SO") {?> SELECTED <?php } ?>>ソマリア連邦共和国</option>
<option value="ZA"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="ZA") {?> SELECTED <?php } ?>>南アフリカ共和国</option>
<option value="SS"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="SS") {?> SELECTED <?php } ?>>南スーダン共和国</option>
<option value="ES"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="ES") {?> SELECTED <?php } ?>>スペイン</option>
<option value="LK"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="LK") {?> SELECTED <?php } ?>>スリランカ民主社会主義共和国</option>
<option value="SR"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="SR") {?> SELECTED <?php } ?>>スリナム共和国</option>
<option value="SJ"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="SJ") {?> SELECTED <?php } ?>>スバールバル諸島とヤンマイエン</オプション></option>
<option value="SZ"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="SZ") {?> SELECTED <?php } ?>>スワジランド王国</option>
<option value="SE"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="SE") {?> SELECTED <?php } ?>>スウェーデン王国</option>
<option value="CH"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="CH") {?> SELECTED <?php } ?>>スイス連邦</option>
<option value="SY"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="SY") {?> SELECTED <?php } ?>>シリア・アラブ共和国</option>
<option value="TW"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="TW") {?> SELECTED <?php } ?>>台湾</option>
<option value="TJ"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="TJ") {?> SELECTED <?php } ?>>タジキスタン共和国</option>
<option value="TZ"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="TZ") {?> SELECTED <?php } ?>>タンザニア連合共和国</option>
<option value="TH"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="TH") {?> SELECTED <?php } ?>>タイ王国</option>
<option value="TL"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="TL") {?> SELECTED <?php } ?>>東ティモール民主共和国</option>
<option value="TG"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="TG") {?> SELECTED <?php } ?>>トーゴ共和国</option>
<option value="TO"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="TO") {?> SELECTED <?php } ?>>トンガ王国 </option>
<option value="TT"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="TT") {?> SELECTED <?php } ?>>トリニダード・トバゴ共和国</option>
<option value="TN"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="TN") {?> SELECTED <?php } ?>>チュニジア共和国</option>
<option value="TR"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="TR") {?> SELECTED <?php } ?>>トルコ共和国</option>
<option value="TM"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="TM") {?> SELECTED <?php } ?>>トルクメニスタン</option>
<option value="TV"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="TV") {?> SELECTED <?php } ?>>ツバル</option>
<option value="UG"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="UG") {?> SELECTED <?php } ?>>ウガンダ共和国</option>
<option value="UA"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="UA") {?> SELECTED <?php } ?>>ウクライナ</option>
<option value="AE"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="AE") {?> SELECTED <?php } ?>>アラブ首長国連邦</option>
<option value="GB"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="GB") {?> SELECTED <?php } ?>>イギリス（グレートブリテン及び北アイルランド連合王国）およびその海外領土</option>
<option value="US"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="US") {?> SELECTED <?php } ?>>アメリカ合衆国およびその国外諸島・自治領</option>
<option value="UY"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="UY") {?> SELECTED <?php } ?>>ウルグアイ東方共和国</option>
<option value="UZ"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="UZ") {?> SELECTED <?php } ?>>ウズベキスタン共和国</option>
<option value="VU"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="VU") {?> SELECTED <?php } ?>>バヌアツ共和国</option>
<option value="VE"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="VE") {?> SELECTED <?php } ?>>ベネズエラ・ボリバル共和国</option>
<option value="VN"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="VN") {?> SELECTED <?php } ?>>ベトナム社会主義共和国</option>
<option value="YE"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="YE") {?> SELECTED <?php } ?>>イエメン共和国 </option>
<option value="ZM"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="ZM") {?> SELECTED <?php } ?>>ザンビア共和国</option>
<option value="ZW"<?php if(isset($_SESSION['cu_where'])&&$_SESSION['cu_where']=="ZW") {?> SELECTED <?php } ?>>ジンバブエ共和国</option>
</select>
        </td>
    </tr>
    <tr style="background:#eee">
        <td style="width:200px"><?php echo $pagetexts['cu_return_age'];?></td>
        <td>
            <select name="cu_return_age" id="conditi3">
            <option value=""><?php echo $pagetexts['select']?></option>   
            <?php
                for($i=0;$i<100;$i++){
                    $str="";
                    if(isset($_SESSION['cu_return_age'])&&$i==$_SESSION['cu_return_age']) $str=" SELECTED ";
                    if($i==0 && !isset($_SESSION['cu_return_age'])) $str=" SELECTED ";
                    echo "<option value=\"$i\"  $str>$i</option>";  
                }
            ?>
            </select> 
            <?php echo $pagetexts['rp_years_ago'];?>
        </td>
    </tr>
     
</table>
<button id="navigationbutton" onclick="history.go(-1);"><?php echo $pagetexts['back'];?> </button>
<input id="navigationbutton" type="submit" value="<?php echo $pagetexts['forward'];?>" style="float:right;margin-right:50px;">
</form>

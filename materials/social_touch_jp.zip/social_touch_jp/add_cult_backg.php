<?php
include('lib.php');
    session_start();
    $userID=$_POST['userID'];
$data="";
// check that we have all variables
$keys=array('cu_mother', 'cu_father','cu_born','cu_extended_stay','cu_how_long','cu_where','cu_return_age');

$err=-1;
echo $keys;    
for($k=0;$k<count($keys);$k++){
    if(isset($_POST[$keys[$k]]))
    {
    $_SESSION[$keys[$k]]=$_POST[$keys[$k]];
    }
}
    echo print_r($_POST);
    echo "<br> has extended stay:".$_POST['cu_extended_stay'];
    if(isset($_POST['cu_extended_stay']) AND $_POST['cu_extended_stay']==1){
        $countto = count($keys);
    } else {
        $countto = 4;
    }
    echo "<br> how many keys:".$countto;
    
for($k=0;$k<$countto;$k++){
    if(!isset($_POST[$keys[$k]]) OR strlen($_POST[$keys[$k]])==0)
    {
        $err=$k;
        break;
    }
    else
    {
        $data.=htmlspecialchars($_POST[$keys[$k]]).",";
    }
}
if($countto<count($keys)){
    for($diff=0;$diff<(count($keys)-$countto);$diff++){
        $data.="-1,";
    }
}        
if($err>=0)
{
        header("Location: cultural_background.php?err=$err&userID=$userID");
}
else
{
    $data.="\n";
    $file="subjects/$userID/cultural_background.txt";
    $fh = fopen($file, 'a') or die("There was a disk error. Please email enrico.glerean@aalto.fi");
    fwrite($fh, $data);
    fclose($fh);
    
header("Location: select_people.php?userID=$userID");
}
?>

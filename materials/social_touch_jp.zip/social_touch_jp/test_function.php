<?php
include_once('lib.php');
include_once('settings.php');
include('header.php');
    $userID=$_GET['userID'];

$thing = whereToGo($userID);
header("Location: $thing?userID=$userID");

?>

<?php
include_once('settings.php');
include_once('lib.php');

include('header.php');
    session_unset();
    ?>
<div id ="header">
<div style="top:0px;float:right;margin-right:10px;color:#ccc"><a href="admin/index.php">Admin</a></div>
<h1><?php echo $title; ?></h1>
</div>

<div id="container">
<?php


?>
<div id="intro" >
あなたの入力したIDは正しくないかまたは有効になっておりません。IDを再度ご確認いただければ幸いです。
<br><a href="index.php"> 戻る </a>

</div>

<?php
include('footer.php');
?>
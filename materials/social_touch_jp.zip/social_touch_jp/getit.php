<?php
$xt=$_POST['arrX'];
$yt=$_POST['arrY'];
$t=$_POST['arrTime'];
$xtd=$_POST['arrXD'];
$ytd=$_POST['arrYD'];
$td=$_POST['arrTimeD'];
$mdt=$_POST['arrMD'];
$mut=$_POST['arrMU'];
$file=$_POST['file'];
$techfile=$_POST['techf'];
$win_height = $_POST['winheight'];
$scr_height = $_POST['scrheight'];
$cli_height = $_POST['cliheight'];
$win_width = $_POST['winwidth'];
$scr_width = $_POST['scrwidth'];
$cli_width = $_POST['cliwidth'];

$techdata=var_export($_SERVER,TRUE);
// input verification if someone wants
if(!isset($xt) || !isset($yt) || !isset($t) || !isset($mdt) || !isset($mut))
      echo "ERROR: some variables are missing\n";

// let's build the text based on what we have

$mytext="";
if(!empty($xt))
{

	for($c=0;$c<count($xt);$c++){
 	   $mytext.=$t[$c].",".$xt[$c].",".$yt[$c]."\n";
	}
}
// add a separator
$mytext.="-1,-1,-1\n";

// add the drawing data
if(!empty($xtd))
{	for($c=0;$c<count($xtd);$c++){
	    $mytext.=$td[$c].",".$xtd[$c].",".$ytd[$c]."\n";
	}
}
// add a separator
$mytext.="-1,-1,-1\n";

if(!empty($mdt))
{
	for($c=0;$c<count($mdt);$c++){
    	$mytext.=$mdt[$c].",,\n";
	}
}

// add a separator
$mytext.="-1,-1,-1\n";

if(!empty($mut))
{
	for($c=0;$c<count($mut);$c++){
        $mytext.=$mut[$c].",,\n";
	}
}   

$arr=explode('/',$file);     //0 is the ., 1 is subjects, 2 is subject id, 3 is the presentation file
$subject=$arr[2];
$fh = fopen($file, 'w') or die("2");
fwrite($fh, $mytext);
fclose($fh);
$ft=fopen($techfile,'a') or die("4");
$towrite = 'win height: '.$win_height."\nscr height: ".$scr_height."\ncli height: ".$cli_height."\nwin width: ".$win_width."\nscr width: ".$scr_width."\ncli width: ".$cli_width."\n".$techdata;
fwrite($ft, $towrite);
fclose($ft);
echo "1";


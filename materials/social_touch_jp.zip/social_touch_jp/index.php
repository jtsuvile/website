<?php
include_once('settings.php');
include_once('lib.php');

include('header.php');
    session_unset();
    ?>
<div id ="header">
<div style="top:0px;float:right;margin-right:10px;color:#ccc"><a href="admin/index.php">Admin</a></div>
<h1><?php echo $title; ?></h1>
</div>

<div id="container">
<?php

$login1=$pagetexts['login1'];
$login2=$pagetexts['login2'];
$login3=$pagetexts['login3'];

$register=$pagetexts['register'];
?>
<div id="intro" style="margin-top:40px;">
本研究では、社会的コミュニケーション手段としての触覚について調べます。この研究では特に、触ることが許される体の部位は人によってどう異なるかに注目します。質問票は2部構成で、すべての質問に答えるには最長で30分かかります。第1部では社会的なネットワークと、社会的触覚全般についてお尋ねします。第2部では社会的ネットワークの構成員に、自分が不快に感じない範囲で、触ることを許せる体の部位についてお尋ねします。
<br><br>
参加は自由ですので、ご希望に応じて中断してかまいません。ただしポイントは、マイボイスコムから配布される正しいIDを打ち込み、かつ全ての質問に回答した方にのみ支払います。データはすべて、研究チームのメンバー以外が扱うことはありません。回答内容によって、回答者の身元が特定されることはありません。この調査は、生理学研究所の北田亮、原田宗子、定藤規弘、アールト大学のジュリア・スヴィレート、リータ・ハリ、ローリ・ヌメンマー、およびマックスプランク研究所のロバート・ターナーが実施します。

<form id="intro" method="GET" onsubmit="return confirmAction()" action="navigator.php">

<?php echo $login1;?>

<input style="font-size:12px;margin-bottom:10px;" name="userID" type="text" onclick="this.value=''" value="<?php echo $login2;?>"> 
<br>
<?php echo $login3;?><br><br>
一度次のページに移ると前のページに戻れませんので、ご注意ください
</p>
</p>
</div>

<?php
include('footer.php');
?>

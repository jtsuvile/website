<?php
include_once('lib.php');
include_once('settings.php');
include('header.php');

$userID=$_GET['userID'];

$thing = whereToGo($userID);
if ($thing==FALSE){
    header("Location: invalid_subject.php");
    exit();
} else {
    header("Location: $thing?userID=$userID");
}

?>

<?php
include_once('lib.php');
include_once('settings.php');
include('header.php');

if(array_key_exists('err',$_GET))
	$err=$_GET['err'];
    $userID=$_GET['userID'];
    $presentation=loadTxt("./subjects/$userID/presentation.txt",0);
    
    $keys=array('rel', 'kid','mom','dad','sis','bro','aunt','uncle','f_cousin','m_cousin','f_friend','m_friend', 'f_contact', 'm_contact', 'niece', 'nephew', 'r_f','r_m', 'r_f_tod', 'r_m_tod');
    
    if(isset($err))
    {
        $loc = $keys[$err];
        $msg=$pagetexts['bg_err'].' '.$pagetexts[$loc];
        $errormsg="<br><div class=\"error\">$msg</div><br><br>";
    }

?>
<div id="header">
<h1><?php echo $pagetexts['bg_4_title'];?></h1></div>
<div id="container">
<div style="padding-left:10px">
<?php $width = 350;?>
<style>
td{
    padding:10px;
    }
input{
    margin-right:3px;
    }
</style>
<br>
<i><?php echo $pagetexts['bg_4_text'];?></i>
<br>
<?php if(isset($errormsg)) echo $errormsg; ?>

<form method="POST" action="bg_check_4.php">
<input type="hidden" name="userID" value="<?php echo $userID; ?>" />
<table>

    <tr style="background:#ccc">
        <th style="width:300px">  </th>
        <th style="width:70px"><?php echo $pagetexts['bg_1_pleas'];?></th>
        <th style="width:70px"> 2 </th>
        <th style="width:70px"> 3 </th>
        <th style="width:70px"> 4 </th>
        <th style="width:70px"> 5 </th>
        <th style="width:70px"> 6 </th>
        <th style="width:70px"> 7 </th>
        <th style="width:70px"> 8 </th>
        <th style="width:70px"> 9 </th>
        <th style="width:70px"><?php echo $pagetexts['bg_10_pleas'];?></th>
    </tr>

<?php
    $n = 1;
    for($i = 0; $i <= count($presentation)-2; $i++) {
        if($n%2==0){ ?> <tr style="background:#ccc">
<?php ;} else { ?> <tr style="background:#eee"> <?php ;}
    $term = $keys[$presentation[$i]];
    $assumed = $term.'_assumed';
    ?>
<td><?php echo $pagetexts[$term];?></td>
        <td> <input type="radio" name=<?php echo $assumed ?> value="1" <?php if(isset($_SESSION[$assumed])&&$_SESSION[$assumed]==="1"){?>checked="checked"<?php }?>></td>
        <td> <input type="radio" name=<?php echo $assumed ?> value="2" <?php if(isset($_SESSION[$assumed])&&$_SESSION[$assumed]==="2"){?>checked="checked"<?php }?>></td>
        <td> <input type="radio" name=<?php echo $assumed ?> value="3" <?php if(isset($_SESSION[$assumed])&&$_SESSION[$assumed]==="3"){?>checked="checked"<?php }?>></td>
        <td> <input type="radio" name=<?php echo $assumed ?> value="4" <?php if(isset($_SESSION[$assumed])&&$_SESSION[$assumed]==="4"){?>checked="checked"<?php }?>></td>
        <td> <input type="radio" name=<?php echo $assumed ?> value="5" <?php if(isset($_SESSION[$assumed])&&$_SESSION[$assumed]==="5"){?>checked="checked"<?php }?>></td>
        <td> <input type="radio" name=<?php echo $assumed ?> value="6" <?php if(isset($_SESSION[$assumed])&&$_SESSION[$assumed]==="6"){?>checked="checked"<?php }?>></td>
        <td> <input type="radio" name=<?php echo $assumed ?> value="7" <?php if(isset($_SESSION[$assumed])&&$_SESSION[$assumed]==="7"){?>checked="checked"<?php }?>></td>
        <td> <input type="radio" name=<?php echo $assumed ?> value="8" <?php if(isset($_SESSION[$assumed])&&$_SESSION[$assumed]==="8"){?>checked="checked"<?php }?>></td>
        <td> <input type="radio" name=<?php echo $assumed ?> value="9" <?php if(isset($_SESSION[$assumed])&&$_SESSION[$assumed]==="9"){?>checked="checked"<?php }?>></td>
        <td> <input type="radio" name=<?php echo $assumed ?> value="10" <?php if(isset($_SESSION[$assumed])&&$_SESSION[$assumed]==="10"){?>checked="checked"<?php }?>></td>
    </tr>
    
<?php $n = $n+1; }
    
    if(count($keys)-count($presentation) > 0){
        for($j=0; $j <= count($keys)-1; $j++) {
            if(!(in_array($j, $presentation))){
                $term = $keys[$j];
                $assumed = $term.'_assumed';?>
                <input type="hidden" name=<?php echo $assumed ?> value="-1">
<?php
            }
        }
    }
    
    ?>

</table>
<input type="submit" value="<?php echo $pagetexts['forward'];?>" style="margin-top:10px;width:320px;font-size:20px;">
<button id="navigationbutton" onclick="history.go(-1);"><?php echo $pagetexts['back'];?> </button>
<input id="navigationbutton" type="submit" value="<?php echo $pagetexts['forward'];?>" style="float:right;margin-right:50px;">
</form>
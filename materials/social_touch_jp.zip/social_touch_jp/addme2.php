<?php
    include('lib.php');
        session_start();
    $userID=$_POST['userID'];
    
    $data="";
// check that we have all variables
$keys=array('rel','kid','mom','dad','sis','bro','niece','nephew','aunt','uncle','f_cousin','m_cousin','f_friend','m_friend', 'f_contact', 'm_contact');

    for($k=0;$k<count($keys);$k++){
        if(isset($_POST[$keys[$k]]))
        {
            $_SESSION[$keys[$k]]=$_POST[$keys[$k]];
        }
    }
    
$err=-1;
for($k=0;$k<count($keys);$k++){
    if(!isset($_POST[$keys[$k]]))
    {
        $err=$k;
        break;
    }
    else
    {
        $data.=$_POST[$keys[$k]].",";
    }
}
        
if($err>=0)
{
        header("Location: select_people.php?err=$err&userID=$userID");
}
else
{
$techdata=var_export($_SERVER,TRUE);

$file="subjects/$userID/select_people.txt";
$fh = fopen($file, 'w') or die("There was a disk error. Please email enrico.glerean@aalto.fi");
fwrite($fh, $data);
fclose($fh);

$file="subjects/$userID/techdata.txt";
$fh = fopen($file, 'w') or die("There was a disk error. Please email enrico.glerean@aalto.fi");
fwrite($fh, $techdata);
fclose($fh);
    
// does the subject already have a presentation file?
    $pfpath='./subjects/'.$userID.'/presentation.txt';
    makePresentation($pfpath);

header("Location: background1.php?userID=$userID");
}
?>
